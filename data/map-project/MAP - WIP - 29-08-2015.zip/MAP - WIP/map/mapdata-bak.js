var mapData =[
  {
    "name": "1",
    "position": {
      "x": 875,
      "y": -708,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 1,
    "py\/object": "star.Star"
  },
  {
    "name": "2",
    "position": {
      "x": -189,
      "y": -685,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 2,
    "py\/object": "star.Star"
  },
  {
    "name": "3",
    "position": {
      "x": 465,
      "y": -672,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 3,
    "py\/object": "star.Star"
  },
  {
    "name": "4",
    "position": {
      "x": 233,
      "y": -672,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 4,
    "py\/object": "star.Star"
  },
  {
    "name": "5",
    "position": {
      "x": -130,
      "y": -671,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 5,
    "py\/object": "star.Star"
  },
  {
    "name": "6",
    "position": {
      "x": -496,
      "y": -653,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 6,
    "py\/object": "star.Star"
  },
  {
    "name": "7",
    "position": {
      "x": 357,
      "y": -622,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 7,
    "py\/object": "star.Star"
  },
  {
    "name": "8",
    "position": {
      "x": -124,
      "y": -623,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 8,
    "py\/object": "star.Star"
  },
  {
    "name": "9",
    "position": {
      "x": -389,
      "y": -604,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 9,
    "py\/object": "star.Star"
  },
  {
    "name": "10",
    "position": {
      "x": -311,
      "y": -597,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 10,
    "py\/object": "star.Star"
  },
  {
    "name": "11",
    "position": {
      "x": 327,
      "y": -587,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 11,
    "py\/object": "star.Star"
  },
  {
    "name": "12",
    "position": {
      "x": -933,
      "y": -575,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 12,
    "py\/object": "star.Star"
  },
  {
    "name": "13",
    "position": {
      "x": -920,
      "y": -564,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 13,
    "py\/object": "star.Star"
  },
  {
    "name": "14",
    "position": {
      "x": -1294,
      "y": -558,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 14,
    "py\/object": "star.Star"
  },
  {
    "name": "15",
    "position": {
      "x": 604,
      "y": -558,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 15,
    "py\/object": "star.Star"
  },
  {
    "name": "16",
    "position": {
      "x": 430,
      "y": -552,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 16,
    "py\/object": "star.Star"
  },
  {
    "name": "17",
    "position": {
      "x": 948,
      "y": -537,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 17,
    "py\/object": "star.Star"
  },
  {
    "name": "18",
    "position": {
      "x": -218,
      "y": -535,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 18,
    "py\/object": "star.Star"
  },
  {
    "name": "19",
    "position": {
      "x": 350,
      "y": -521,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 19,
    "py\/object": "star.Star"
  },
  {
    "name": "20",
    "position": {
      "x": -118,
      "y": -518,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 20,
    "py\/object": "star.Star"
  },
  {
    "name": "21",
    "position": {
      "x": -126,
      "y": -501,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 21,
    "py\/object": "star.Star"
  },
  {
    "name": "22",
    "position": {
      "x": -320,
      "y": -493,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 22,
    "py\/object": "star.Star"
  },
  {
    "name": "23",
    "position": {
      "x": 1252,
      "y": -484,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 23,
    "py\/object": "star.Star"
  },
  {
    "name": "24",
    "position": {
      "x": 293,
      "y": -478,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 24,
    "py\/object": "star.Star"
  },
  {
    "name": "25",
    "position": {
      "x": -12,
      "y": -480,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 25,
    "py\/object": "star.Star"
  },
  {
    "name": "26",
    "position": {
      "x": -1216,
      "y": -475,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 26,
    "py\/object": "star.Star"
  },
  {
    "name": "27",
    "position": {
      "x": 1009,
      "y": -475,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 27,
    "py\/object": "star.Star"
  },
  {
    "name": "28",
    "position": {
      "x": -274,
      "y": -475,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 28,
    "py\/object": "star.Star"
  },
  {
    "name": "29",
    "position": {
      "x": -1005,
      "y": -468,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 29,
    "py\/object": "star.Star"
  },
  {
    "name": "30",
    "position": {
      "x": 853,
      "y": -463,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 30,
    "py\/object": "star.Star"
  },
  {
    "name": "31",
    "position": {
      "x": 1385,
      "y": -450,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 31,
    "py\/object": "star.Star"
  },
  {
    "name": "32",
    "position": {
      "x": 474,
      "y": -445,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 32,
    "py\/object": "star.Star"
  },
  {
    "name": "33",
    "position": {
      "x": -448,
      "y": -444,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 33,
    "py\/object": "star.Star"
  },
  {
    "name": "34",
    "position": {
      "x": 1167,
      "y": -442,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 34,
    "py\/object": "star.Star"
  },
  {
    "name": "35",
    "position": {
      "x": -621,
      "y": -436,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 35,
    "py\/object": "star.Star"
  },
  {
    "name": "36",
    "position": {
      "x": -1150,
      "y": -436,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 36,
    "py\/object": "star.Star"
  },
  {
    "name": "37",
    "position": {
      "x": 1146,
      "y": -433,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 37,
    "py\/object": "star.Star"
  },
  {
    "name": "38",
    "position": {
      "x": -88,
      "y": -433,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 38,
    "py\/object": "star.Star"
  },
  {
    "name": "39",
    "position": {
      "x": -956,
      "y": -430,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 39,
    "py\/object": "star.Star"
  },
  {
    "name": "40",
    "position": {
      "x": 222,
      "y": -431,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 40,
    "py\/object": "star.Star"
  },
  {
    "name": "41",
    "position": {
      "x": 1058,
      "y": -425,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 41,
    "py\/object": "star.Star"
  },
  {
    "name": "42",
    "position": {
      "x": -74,
      "y": -411,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 42,
    "py\/object": "star.Star"
  },
  {
    "name": "43",
    "position": {
      "x": -1490,
      "y": -404,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 43,
    "py\/object": "star.Star"
  },
  {
    "name": "44",
    "position": {
      "x": 42,
      "y": -387,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 44,
    "py\/object": "star.Star"
  },
  {
    "name": "45",
    "position": {
      "x": -969,
      "y": -381,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 45,
    "py\/object": "star.Star"
  },
  {
    "name": "46",
    "position": {
      "x": -250,
      "y": -365,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 46,
    "py\/object": "star.Star"
  },
  {
    "name": "47",
    "position": {
      "x": -1832,
      "y": -363,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 47,
    "py\/object": "star.Star"
  },
  {
    "name": "48",
    "position": {
      "x": 897,
      "y": -360,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 48,
    "py\/object": "star.Star"
  },
  {
    "name": "49",
    "position": {
      "x": 12,
      "y": -356,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 49,
    "py\/object": "star.Star"
  },
  {
    "name": "50",
    "position": {
      "x": -105,
      "y": -355,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 50,
    "py\/object": "star.Star"
  },
  {
    "name": "51",
    "position": {
      "x": -248,
      "y": -349,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 51,
    "py\/object": "star.Star"
  },
  {
    "name": "52",
    "position": {
      "x": 433,
      "y": -350,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 52,
    "py\/object": "star.Star"
  },
  {
    "name": "53",
    "position": {
      "x": 384,
      "y": -348,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 53,
    "py\/object": "star.Star"
  },
  {
    "name": "54",
    "position": {
      "x": -1330,
      "y": -343,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 54,
    "py\/object": "star.Star"
  },
  {
    "name": "55",
    "position": {
      "x": 1229,
      "y": -345,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 55,
    "py\/object": "star.Star"
  },
  {
    "name": "56",
    "position": {
      "x": -1197,
      "y": -341,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 56,
    "py\/object": "star.Star"
  },
  {
    "name": "57",
    "position": {
      "x": -1092,
      "y": -337,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 57,
    "py\/object": "star.Star"
  },
  {
    "name": "58",
    "position": {
      "x": -2246,
      "y": -335,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 58,
    "py\/object": "star.Star"
  },
  {
    "name": "59",
    "position": {
      "x": 279,
      "y": -321,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 59,
    "py\/object": "star.Star"
  },
  {
    "name": "60",
    "position": {
      "x": 910,
      "y": -311,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 60,
    "py\/object": "star.Star"
  },
  {
    "name": "61",
    "position": {
      "x": -1166,
      "y": -309,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 61,
    "py\/object": "star.Star"
  },
  {
    "name": "62",
    "position": {
      "x": -32,
      "y": -307,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 62,
    "py\/object": "star.Star"
  },
  {
    "name": "63",
    "position": {
      "x": 2249,
      "y": -305,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 63,
    "py\/object": "star.Star"
  },
  {
    "name": "64",
    "position": {
      "x": 1621,
      "y": -305,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 64,
    "py\/object": "star.Star"
  },
  {
    "name": "65",
    "position": {
      "x": -73,
      "y": -303,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 65,
    "py\/object": "star.Star"
  },
  {
    "name": "66",
    "position": {
      "x": -1551,
      "y": -301,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 66,
    "py\/object": "star.Star"
  },
  {
    "name": "67",
    "position": {
      "x": 10,
      "y": -293,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 67,
    "py\/object": "star.Star"
  },
  {
    "name": "68",
    "position": {
      "x": 1012,
      "y": -291,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 68,
    "py\/object": "star.Star"
  },
  {
    "name": "69",
    "position": {
      "x": -94,
      "y": -287,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 69,
    "py\/object": "star.Star"
  },
  {
    "name": "70",
    "position": {
      "x": -1003,
      "y": -288,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 70,
    "py\/object": "star.Star"
  },
  {
    "name": "71",
    "position": {
      "x": 415,
      "y": -274,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 71,
    "py\/object": "star.Star"
  },
  {
    "name": "72",
    "position": {
      "x": -1019,
      "y": -271,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 72,
    "py\/object": "star.Star"
  },
  {
    "name": "73",
    "position": {
      "x": 584,
      "y": -246,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 73,
    "py\/object": "star.Star"
  },
  {
    "name": "74",
    "position": {
      "x": 2021,
      "y": -240,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 74,
    "py\/object": "star.Star"
  },
  {
    "name": "75",
    "position": {
      "x": -617,
      "y": -211,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 75,
    "py\/object": "star.Star"
  },
  {
    "name": "76",
    "position": {
      "x": -925,
      "y": -209,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 76,
    "py\/object": "star.Star"
  },
  {
    "name": "77",
    "position": {
      "x": -1848,
      "y": -208,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 77,
    "py\/object": "star.Star"
  },
  {
    "name": "78",
    "position": {
      "x": -269,
      "y": -202,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 78,
    "py\/object": "star.Star"
  },
  {
    "name": "79",
    "position": {
      "x": -1011,
      "y": -195,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 79,
    "py\/object": "star.Star"
  },
  {
    "name": "80",
    "position": {
      "x": -1186,
      "y": -197,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 80,
    "py\/object": "star.Star"
  },
  {
    "name": "81",
    "position": {
      "x": -1189,
      "y": -182,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 81,
    "py\/object": "star.Star"
  },
  {
    "name": "82",
    "position": {
      "x": 2125,
      "y": -174,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 82,
    "py\/object": "star.Star"
  },
  {
    "name": "83",
    "position": {
      "x": 329,
      "y": -166,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 83,
    "py\/object": "star.Star"
  },
  {
    "name": "84",
    "position": {
      "x": -2135,
      "y": -167,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 84,
    "py\/object": "star.Star"
  },
  {
    "name": "85",
    "position": {
      "x": -1007,
      "y": -164,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 85,
    "py\/object": "star.Star"
  },
  {
    "name": "86",
    "position": {
      "x": 1157,
      "y": -150,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 86,
    "py\/object": "star.Star"
  },
  {
    "name": "87",
    "position": {
      "x": -363,
      "y": -151,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 87,
    "py\/object": "star.Star"
  },
  {
    "name": "88",
    "position": {
      "x": 1880,
      "y": -142,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 88,
    "py\/object": "star.Star"
  },
  {
    "name": "89",
    "position": {
      "x": -1057,
      "y": -131,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 89,
    "py\/object": "star.Star"
  },
  {
    "name": "90",
    "position": {
      "x": 1411,
      "y": -127,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 90,
    "py\/object": "star.Star"
  },
  {
    "name": "91",
    "position": {
      "x": 772,
      "y": -124,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 91,
    "py\/object": "star.Star"
  },
  {
    "name": "92",
    "position": {
      "x": -2075,
      "y": -118,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 92,
    "py\/object": "star.Star"
  },
  {
    "name": "93",
    "position": {
      "x": 347,
      "y": -108,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 93,
    "py\/object": "star.Star"
  },
  {
    "name": "94",
    "position": {
      "x": 1796,
      "y": -106,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 94,
    "py\/object": "star.Star"
  },
  {
    "name": "95",
    "position": {
      "x": -611,
      "y": -96,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 95,
    "py\/object": "star.Star"
  },
  {
    "name": "96",
    "position": {
      "x": -1492,
      "y": -88,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 96,
    "py\/object": "star.Star"
  },
  {
    "name": "97",
    "position": {
      "x": -568,
      "y": -88,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 97,
    "py\/object": "star.Star"
  },
  {
    "name": "98",
    "position": {
      "x": 1584,
      "y": -87,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 98,
    "py\/object": "star.Star"
  },
  {
    "name": "99",
    "position": {
      "x": 561,
      "y": -84,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 99,
    "py\/object": "star.Star"
  },
  {
    "name": "100",
    "position": {
      "x": -953,
      "y": -85,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 100,
    "py\/object": "star.Star"
  },
  {
    "name": "101",
    "position": {
      "x": 1307,
      "y": -64,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 101,
    "py\/object": "star.Star"
  },
  {
    "name": "102",
    "position": {
      "x": -2337,
      "y": -63,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 102,
    "py\/object": "star.Star"
  },
  {
    "name": "103",
    "position": {
      "x": -359,
      "y": -65,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 103,
    "py\/object": "star.Star"
  },
  {
    "name": "104",
    "position": {
      "x": 1733,
      "y": -60,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 104,
    "py\/object": "star.Star"
  },
  {
    "name": "105",
    "position": {
      "x": -1012,
      "y": -54,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 105,
    "py\/object": "star.Star"
  },
  {
    "name": "106",
    "position": {
      "x": 803,
      "y": -50,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 106,
    "py\/object": "star.Star"
  },
  {
    "name": "107",
    "position": {
      "x": 1854,
      "y": -42,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 107,
    "py\/object": "star.Star"
  },
  {
    "name": "108",
    "position": {
      "x": 1524,
      "y": -39,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 108,
    "py\/object": "star.Star"
  },
  {
    "name": "109",
    "position": {
      "x": 1606,
      "y": -35,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 109,
    "py\/object": "star.Star"
  },
  {
    "name": "110",
    "position": {
      "x": -1357,
      "y": -22,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 110,
    "py\/object": "star.Star"
  },
  {
    "name": "111",
    "position": {
      "x": 2367,
      "y": -19,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 111,
    "py\/object": "star.Star"
  },
  {
    "name": "112",
    "position": {
      "x": -18,
      "y": -8,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 112,
    "py\/object": "star.Star"
  },
  {
    "name": "113",
    "position": {
      "x": 1774,
      "y": -3,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 113,
    "py\/object": "star.Star"
  },
  {
    "name": "Terra",
    "position": {
      "x": 0,
      "y": 0,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 114,
    "py\/object": "star.Star"
  },
  {
    "name": "115",
    "position": {
      "x": 1483,
      "y": 2,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 115,
    "py\/object": "star.Star"
  },
  {
    "name": "116",
    "position": {
      "x": 566,
      "y": 4,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 116,
    "py\/object": "star.Star"
  },
  {
    "name": "117",
    "position": {
      "x": 912,
      "y": 10,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 117,
    "py\/object": "star.Star"
  },
  {
    "name": "118",
    "position": {
      "x": 1665,
      "y": 16,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 118,
    "py\/object": "star.Star"
  },
  {
    "name": "119",
    "position": {
      "x": -147,
      "y": 17,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 119,
    "py\/object": "star.Star"
  },
  {
    "name": "120",
    "position": {
      "x": 2079,
      "y": 21,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 120,
    "py\/object": "star.Star"
  },
  {
    "name": "121",
    "position": {
      "x": 1942,
      "y": 28,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 121,
    "py\/object": "star.Star"
  },
  {
    "name": "122",
    "position": {
      "x": 1354,
      "y": 29,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 122,
    "py\/object": "star.Star"
  },
  {
    "name": "123",
    "position": {
      "x": 1609,
      "y": 40,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 123,
    "py\/object": "star.Star"
  },
  {
    "name": "124",
    "position": {
      "x": 1762,
      "y": 39,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 124,
    "py\/object": "star.Star"
  },
  {
    "name": "125",
    "position": {
      "x": 1562,
      "y": 43,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 125,
    "py\/object": "star.Star"
  },
  {
    "name": "126",
    "position": {
      "x": 1883,
      "y": 46,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 126,
    "py\/object": "star.Star"
  },
  {
    "name": "127",
    "position": {
      "x": 2427,
      "y": 47,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 127,
    "py\/object": "star.Star"
  },
  {
    "name": "128",
    "position": {
      "x": 789,
      "y": 51,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 128,
    "py\/object": "star.Star"
  },
  {
    "name": "129",
    "position": {
      "x": 129,
      "y": 54,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 129,
    "py\/object": "star.Star"
  },
  {
    "name": "130",
    "position": {
      "x": 999,
      "y": 62,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 130,
    "py\/object": "star.Star"
  },
  {
    "name": "131",
    "position": {
      "x": 1827,
      "y": 68,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 131,
    "py\/object": "star.Star"
  },
  {
    "name": "132",
    "position": {
      "x": -540,
      "y": 83,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 132,
    "py\/object": "star.Star"
  },
  {
    "name": "133",
    "position": {
      "x": 1382,
      "y": 87,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 133,
    "py\/object": "star.Star"
  },
  {
    "name": "134",
    "position": {
      "x": -1658,
      "y": 85,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 134,
    "py\/object": "star.Star"
  },
  {
    "name": "135",
    "position": {
      "x": 1227,
      "y": 88,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 135,
    "py\/object": "star.Star"
  },
  {
    "name": "136",
    "position": {
      "x": 1160,
      "y": 94,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 136,
    "py\/object": "star.Star"
  },
  {
    "name": "137",
    "position": {
      "x": 1938,
      "y": 104,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 137,
    "py\/object": "star.Star"
  },
  {
    "name": "138",
    "position": {
      "x": 751,
      "y": 107,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 138,
    "py\/object": "star.Star"
  },
  {
    "name": "139",
    "position": {
      "x": -177,
      "y": 105,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 139,
    "py\/object": "star.Star"
  },
  {
    "name": "140",
    "position": {
      "x": 1445,
      "y": 108,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 140,
    "py\/object": "star.Star"
  },
  {
    "name": "141",
    "position": {
      "x": -759,
      "y": 106,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 141,
    "py\/object": "star.Star"
  },
  {
    "name": "142",
    "position": {
      "x": -1092,
      "y": 109,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 142,
    "py\/object": "star.Star"
  },
  {
    "name": "143",
    "position": {
      "x": 2012,
      "y": 115,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 143,
    "py\/object": "star.Star"
  },
  {
    "name": "144",
    "position": {
      "x": 2324,
      "y": 122,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 144,
    "py\/object": "star.Star"
  },
  {
    "name": "145",
    "position": {
      "x": 1331,
      "y": 126,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 145,
    "py\/object": "star.Star"
  },
  {
    "name": "146",
    "position": {
      "x": -181,
      "y": 126,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 146,
    "py\/object": "star.Star"
  },
  {
    "name": "147",
    "position": {
      "x": -1945,
      "y": 137,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 147,
    "py\/object": "star.Star"
  },
  {
    "name": "148",
    "position": {
      "x": 1003,
      "y": 140,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 148,
    "py\/object": "star.Star"
  },
  {
    "name": "149",
    "position": {
      "x": 2585,
      "y": 156,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 149,
    "py\/object": "star.Star"
  },
  {
    "name": "150",
    "position": {
      "x": 1534,
      "y": 171,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 150,
    "py\/object": "star.Star"
  },
  {
    "name": "151",
    "position": {
      "x": 1862,
      "y": 169,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 151,
    "py\/object": "star.Star"
  },
  {
    "name": "152",
    "position": {
      "x": -41,
      "y": 172,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 152,
    "py\/object": "star.Star"
  },
  {
    "name": "153",
    "position": {
      "x": 824,
      "y": 174,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 153,
    "py\/object": "star.Star"
  },
  {
    "name": "154",
    "position": {
      "x": 668,
      "y": 177,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 154,
    "py\/object": "star.Star"
  },
  {
    "name": "155",
    "position": {
      "x": 1031,
      "y": 179,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 155,
    "py\/object": "star.Star"
  },
  {
    "name": "156",
    "position": {
      "x": 1456,
      "y": 190,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 156,
    "py\/object": "star.Star"
  },
  {
    "name": "157",
    "position": {
      "x": -1847,
      "y": 192,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 157,
    "py\/object": "star.Star"
  },
  {
    "name": "158",
    "position": {
      "x": 731,
      "y": 208,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 158,
    "py\/object": "star.Star"
  },
  {
    "name": "159",
    "position": {
      "x": 1954,
      "y": 207,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 159,
    "py\/object": "star.Star"
  },
  {
    "name": "160",
    "position": {
      "x": -1174,
      "y": 214,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 160,
    "py\/object": "star.Star"
  },
  {
    "name": "161",
    "position": {
      "x": 1162,
      "y": 221,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 161,
    "py\/object": "star.Star"
  },
  {
    "name": "162",
    "position": {
      "x": 1532,
      "y": 226,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 162,
    "py\/object": "star.Star"
  },
  {
    "name": "163",
    "position": {
      "x": 1665,
      "y": 229,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 163,
    "py\/object": "star.Star"
  },
  {
    "name": "164",
    "position": {
      "x": 2217,
      "y": 231,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 164,
    "py\/object": "star.Star"
  },
  {
    "name": "165",
    "position": {
      "x": -538,
      "y": 230,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 165,
    "py\/object": "star.Star"
  },
  {
    "name": "166",
    "position": {
      "x": -376,
      "y": 244,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 166,
    "py\/object": "star.Star"
  },
  {
    "name": "167",
    "position": {
      "x": 574,
      "y": 244,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 167,
    "py\/object": "star.Star"
  },
  {
    "name": "168",
    "position": {
      "x": 2172,
      "y": 244,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 168,
    "py\/object": "star.Star"
  },
  {
    "name": "169",
    "position": {
      "x": 2304,
      "y": 249,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 169,
    "py\/object": "star.Star"
  },
  {
    "name": "170",
    "position": {
      "x": 373,
      "y": 251,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 170,
    "py\/object": "star.Star"
  },
  {
    "name": "171",
    "position": {
      "x": 1697,
      "y": 256,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 171,
    "py\/object": "star.Star"
  },
  {
    "name": "172",
    "position": {
      "x": 172,
      "y": 257,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 172,
    "py\/object": "star.Star"
  },
  {
    "name": "173",
    "position": {
      "x": 1163,
      "y": 260,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 173,
    "py\/object": "star.Star"
  },
  {
    "name": "174",
    "position": {
      "x": 2471,
      "y": 261,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 174,
    "py\/object": "star.Star"
  },
  {
    "name": "175",
    "position": {
      "x": 292,
      "y": 261,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 175,
    "py\/object": "star.Star"
  },
  {
    "name": "176",
    "position": {
      "x": -64,
      "y": 265,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 176,
    "py\/object": "star.Star"
  },
  {
    "name": "177",
    "position": {
      "x": -752,
      "y": 273,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 177,
    "py\/object": "star.Star"
  },
  {
    "name": "178",
    "position": {
      "x": 2379,
      "y": 274,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 178,
    "py\/object": "star.Star"
  },
  {
    "name": "179",
    "position": {
      "x": 1935,
      "y": 275,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 179,
    "py\/object": "star.Star"
  },
  {
    "name": "180",
    "position": {
      "x": 702,
      "y": 279,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 180,
    "py\/object": "star.Star"
  },
  {
    "name": "181",
    "position": {
      "x": 824,
      "y": 280,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 181,
    "py\/object": "star.Star"
  },
  {
    "name": "182",
    "position": {
      "x": 1211,
      "y": 280,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 182,
    "py\/object": "star.Star"
  },
  {
    "name": "183",
    "position": {
      "x": 764,
      "y": 281,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 183,
    "py\/object": "star.Star"
  },
  {
    "name": "184",
    "position": {
      "x": 2593,
      "y": 288,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 184,
    "py\/object": "star.Star"
  },
  {
    "name": "185",
    "position": {
      "x": -1751,
      "y": 294,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 185,
    "py\/object": "star.Star"
  },
  {
    "name": "186",
    "position": {
      "x": 1635,
      "y": 324,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 186,
    "py\/object": "star.Star"
  },
  {
    "name": "187",
    "position": {
      "x": 2703,
      "y": 325,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 187,
    "py\/object": "star.Star"
  },
  {
    "name": "188",
    "position": {
      "x": 91,
      "y": 326,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 188,
    "py\/object": "star.Star"
  },
  {
    "name": "189",
    "position": {
      "x": 2202,
      "y": 328,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 189,
    "py\/object": "star.Star"
  },
  {
    "name": "190",
    "position": {
      "x": 1729,
      "y": 331,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 190,
    "py\/object": "star.Star"
  },
  {
    "name": "191",
    "position": {
      "x": 878,
      "y": 331,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 191,
    "py\/object": "star.Star"
  },
  {
    "name": "192",
    "position": {
      "x": 2271,
      "y": 337,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 192,
    "py\/object": "star.Star"
  },
  {
    "name": "193",
    "position": {
      "x": 1,
      "y": 337,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 193,
    "py\/object": "star.Star"
  },
  {
    "name": "194",
    "position": {
      "x": -590,
      "y": 335,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 194,
    "py\/object": "star.Star"
  },
  {
    "name": "195",
    "position": {
      "x": -1944,
      "y": 337,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 195,
    "py\/object": "star.Star"
  },
  {
    "name": "196",
    "position": {
      "x": -1213,
      "y": 337,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 196,
    "py\/object": "star.Star"
  },
  {
    "name": "197",
    "position": {
      "x": -1450,
      "y": 340,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 197,
    "py\/object": "star.Star"
  },
  {
    "name": "198",
    "position": {
      "x": -1038,
      "y": 352,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 198,
    "py\/object": "star.Star"
  },
  {
    "name": "199",
    "position": {
      "x": -1126,
      "y": 353,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 199,
    "py\/object": "star.Star"
  },
  {
    "name": "200",
    "position": {
      "x": 1835,
      "y": 353,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 200,
    "py\/object": "star.Star"
  },
  {
    "name": "201",
    "position": {
      "x": 530,
      "y": 353,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 201,
    "py\/object": "star.Star"
  },
  {
    "name": "202",
    "position": {
      "x": 2459,
      "y": 360,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 202,
    "py\/object": "star.Star"
  },
  {
    "name": "203",
    "position": {
      "x": 1197,
      "y": 363,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 203,
    "py\/object": "star.Star"
  },
  {
    "name": "204",
    "position": {
      "x": 854,
      "y": 365,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 204,
    "py\/object": "star.Star"
  },
  {
    "name": "205",
    "position": {
      "x": 1956,
      "y": 372,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 205,
    "py\/object": "star.Star"
  },
  {
    "name": "206",
    "position": {
      "x": 764,
      "y": 373,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 206,
    "py\/object": "star.Star"
  },
  {
    "name": "207",
    "position": {
      "x": 1499,
      "y": 379,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 207,
    "py\/object": "star.Star"
  },
  {
    "name": "208",
    "position": {
      "x": 1015,
      "y": 378,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 208,
    "py\/object": "star.Star"
  },
  {
    "name": "209",
    "position": {
      "x": 228,
      "y": 380,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 209,
    "py\/object": "star.Star"
  },
  {
    "name": "210",
    "position": {
      "x": 1306,
      "y": 383,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 210,
    "py\/object": "star.Star"
  },
  {
    "name": "211",
    "position": {
      "x": 954,
      "y": 383,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 211,
    "py\/object": "star.Star"
  },
  {
    "name": "212",
    "position": {
      "x": 1055,
      "y": 388,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 212,
    "py\/object": "star.Star"
  },
  {
    "name": "213",
    "position": {
      "x": 372,
      "y": 388,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 213,
    "py\/object": "star.Star"
  },
  {
    "name": "214",
    "position": {
      "x": -2043,
      "y": 390,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 214,
    "py\/object": "star.Star"
  },
  {
    "name": "215",
    "position": {
      "x": -114,
      "y": 392,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 215,
    "py\/object": "star.Star"
  },
  {
    "name": "216",
    "position": {
      "x": 2380,
      "y": 394,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 216,
    "py\/object": "star.Star"
  },
  {
    "name": "217",
    "position": {
      "x": -706,
      "y": 401,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 217,
    "py\/object": "star.Star"
  },
  {
    "name": "218",
    "position": {
      "x": 9,
      "y": 408,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 218,
    "py\/object": "star.Star"
  },
  {
    "name": "219",
    "position": {
      "x": -602,
      "y": 409,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 219,
    "py\/object": "star.Star"
  },
  {
    "name": "220",
    "position": {
      "x": 1591,
      "y": 411,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 220,
    "py\/object": "star.Star"
  },
  {
    "name": "221",
    "position": {
      "x": -231,
      "y": 419,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 221,
    "py\/object": "star.Star"
  },
  {
    "name": "222",
    "position": {
      "x": 1358,
      "y": 429,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 222,
    "py\/object": "star.Star"
  },
  {
    "name": "223",
    "position": {
      "x": 869,
      "y": 430,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 223,
    "py\/object": "star.Star"
  },
  {
    "name": "224",
    "position": {
      "x": 2011,
      "y": 435,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 224,
    "py\/object": "star.Star"
  },
  {
    "name": "225",
    "position": {
      "x": -1603,
      "y": 438,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 225,
    "py\/object": "star.Star"
  },
  {
    "name": "226",
    "position": {
      "x": 2208,
      "y": 440,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 226,
    "py\/object": "star.Star"
  },
  {
    "name": "227",
    "position": {
      "x": -1753,
      "y": 442,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 227,
    "py\/object": "star.Star"
  },
  {
    "name": "228",
    "position": {
      "x": -1314,
      "y": 445,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 228,
    "py\/object": "star.Star"
  },
  {
    "name": "229",
    "position": {
      "x": 2388,
      "y": 447,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 229,
    "py\/object": "star.Star"
  },
  {
    "name": "230",
    "position": {
      "x": -725,
      "y": 445,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 230,
    "py\/object": "star.Star"
  },
  {
    "name": "231",
    "position": {
      "x": -993,
      "y": 445,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 231,
    "py\/object": "star.Star"
  },
  {
    "name": "232",
    "position": {
      "x": -150,
      "y": 450,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 232,
    "py\/object": "star.Star"
  },
  {
    "name": "233",
    "position": {
      "x": 996,
      "y": 449,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 233,
    "py\/object": "star.Star"
  },
  {
    "name": "234",
    "position": {
      "x": 800,
      "y": 454,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 234,
    "py\/object": "star.Star"
  },
  {
    "name": "235",
    "position": {
      "x": 505,
      "y": 455,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 235,
    "py\/object": "star.Star"
  },
  {
    "name": "236",
    "position": {
      "x": 712,
      "y": 456,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 236,
    "py\/object": "star.Star"
  },
  {
    "name": "237",
    "position": {
      "x": 299,
      "y": 465,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 237,
    "py\/object": "star.Star"
  },
  {
    "name": "238",
    "position": {
      "x": 1260,
      "y": 467,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 238,
    "py\/object": "star.Star"
  },
  {
    "name": "239",
    "position": {
      "x": -843,
      "y": 470,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 239,
    "py\/object": "star.Star"
  },
  {
    "name": "240",
    "position": {
      "x": 61,
      "y": 470,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 240,
    "py\/object": "star.Star"
  },
  {
    "name": "241",
    "position": {
      "x": 1151,
      "y": 476,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 241,
    "py\/object": "star.Star"
  },
  {
    "name": "242",
    "position": {
      "x": 2422,
      "y": 477,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 242,
    "py\/object": "star.Star"
  },
  {
    "name": "243",
    "position": {
      "x": 18,
      "y": 478,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 243,
    "py\/object": "star.Star"
  },
  {
    "name": "244",
    "position": {
      "x": -251,
      "y": 487,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 244,
    "py\/object": "star.Star"
  },
  {
    "name": "245",
    "position": {
      "x": 2235,
      "y": 491,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 245,
    "py\/object": "star.Star"
  },
  {
    "name": "246",
    "position": {
      "x": 327,
      "y": 489,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 246,
    "py\/object": "star.Star"
  },
  {
    "name": "247",
    "position": {
      "x": -1504,
      "y": 491,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 247,
    "py\/object": "star.Star"
  },
  {
    "name": "248",
    "position": {
      "x": 396,
      "y": 497,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 248,
    "py\/object": "star.Star"
  },
  {
    "name": "249",
    "position": {
      "x": 248,
      "y": 498,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 249,
    "py\/object": "star.Star"
  },
  {
    "name": "250",
    "position": {
      "x": -667,
      "y": 501,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 250,
    "py\/object": "star.Star"
  },
  {
    "name": "251",
    "position": {
      "x": 999,
      "y": 500,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 251,
    "py\/object": "star.Star"
  },
  {
    "name": "252",
    "position": {
      "x": 910,
      "y": 505,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 252,
    "py\/object": "star.Star"
  },
  {
    "name": "253",
    "position": {
      "x": -509,
      "y": 506,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 253,
    "py\/object": "star.Star"
  },
  {
    "name": "254",
    "position": {
      "x": 2252,
      "y": 508,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 254,
    "py\/object": "star.Star"
  },
  {
    "name": "255",
    "position": {
      "x": 419,
      "y": 522,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 255,
    "py\/object": "star.Star"
  },
  {
    "name": "256",
    "position": {
      "x": 207,
      "y": 531,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 256,
    "py\/object": "star.Star"
  },
  {
    "name": "257",
    "position": {
      "x": -1895,
      "y": 534,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 257,
    "py\/object": "star.Star"
  },
  {
    "name": "258",
    "position": {
      "x": -1273,
      "y": 534,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 258,
    "py\/object": "star.Star"
  },
  {
    "name": "259",
    "position": {
      "x": -515,
      "y": 537,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 259,
    "py\/object": "star.Star"
  },
  {
    "name": "260",
    "position": {
      "x": -1603,
      "y": 538,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 260,
    "py\/object": "star.Star"
  },
  {
    "name": "261",
    "position": {
      "x": 2487,
      "y": 541,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 261,
    "py\/object": "star.Star"
  },
  {
    "name": "262",
    "position": {
      "x": 6,
      "y": 546,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 262,
    "py\/object": "star.Star"
  },
  {
    "name": "263",
    "position": {
      "x": -965,
      "y": 548,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 263,
    "py\/object": "star.Star"
  },
  {
    "name": "264",
    "position": {
      "x": -1137,
      "y": 551,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 264,
    "py\/object": "star.Star"
  },
  {
    "name": "265",
    "position": {
      "x": 1472,
      "y": 550,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 265,
    "py\/object": "star.Star"
  },
  {
    "name": "266",
    "position": {
      "x": 883,
      "y": 552,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 266,
    "py\/object": "star.Star"
  },
  {
    "name": "267",
    "position": {
      "x": 427,
      "y": 555,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 267,
    "py\/object": "star.Star"
  },
  {
    "name": "268",
    "position": {
      "x": 289,
      "y": 556,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 268,
    "py\/object": "star.Star"
  },
  {
    "name": "269",
    "position": {
      "x": -155,
      "y": 557,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 269,
    "py\/object": "star.Star"
  },
  {
    "name": "270",
    "position": {
      "x": 207,
      "y": 559,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 270,
    "py\/object": "star.Star"
  },
  {
    "name": "271",
    "position": {
      "x": 749,
      "y": 560,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 271,
    "py\/object": "star.Star"
  },
  {
    "name": "272",
    "position": {
      "x": 393,
      "y": 578,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 272,
    "py\/object": "star.Star"
  },
  {
    "name": "273",
    "position": {
      "x": 771,
      "y": 578,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 273,
    "py\/object": "star.Star"
  },
  {
    "name": "274",
    "position": {
      "x": 66,
      "y": 586,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 274,
    "py\/object": "star.Star"
  },
  {
    "name": "275",
    "position": {
      "x": -255,
      "y": 592,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 275,
    "py\/object": "star.Star"
  },
  {
    "name": "276",
    "position": {
      "x": -402,
      "y": 595,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 276,
    "py\/object": "star.Star"
  },
  {
    "name": "277",
    "position": {
      "x": -528,
      "y": 596,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 277,
    "py\/object": "star.Star"
  },
  {
    "name": "278",
    "position": {
      "x": -700,
      "y": 598,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 278,
    "py\/object": "star.Star"
  },
  {
    "name": "279",
    "position": {
      "x": 1198,
      "y": 601,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 279,
    "py\/object": "star.Star"
  },
  {
    "name": "280",
    "position": {
      "x": -577,
      "y": 601,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 280,
    "py\/object": "star.Star"
  },
  {
    "name": "281",
    "position": {
      "x": -3,
      "y": 611,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 281,
    "py\/object": "star.Star"
  },
  {
    "name": "282",
    "position": {
      "x": 1672,
      "y": 611,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 282,
    "py\/object": "star.Star"
  },
  {
    "name": "283",
    "position": {
      "x": 121,
      "y": 621,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 283,
    "py\/object": "star.Star"
  },
  {
    "name": "284",
    "position": {
      "x": -357,
      "y": 627,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 284,
    "py\/object": "star.Star"
  },
  {
    "name": "285",
    "position": {
      "x": -49,
      "y": 636,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 285,
    "py\/object": "star.Star"
  },
  {
    "name": "286",
    "position": {
      "x": 1052,
      "y": 637,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 286,
    "py\/object": "star.Star"
  },
  {
    "name": "287",
    "position": {
      "x": -346,
      "y": 647,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 287,
    "py\/object": "star.Star"
  },
  {
    "name": "288",
    "position": {
      "x": 1939,
      "y": 661,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 288,
    "py\/object": "star.Star"
  },
  {
    "name": "289",
    "position": {
      "x": 877,
      "y": 663,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 289,
    "py\/object": "star.Star"
  },
  {
    "name": "290",
    "position": {
      "x": 972,
      "y": 663,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 290,
    "py\/object": "star.Star"
  },
  {
    "name": "291",
    "position": {
      "x": 1834,
      "y": 669,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 291,
    "py\/object": "star.Star"
  },
  {
    "name": "292",
    "position": {
      "x": 274,
      "y": 670,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 292,
    "py\/object": "star.Star"
  },
  {
    "name": "293",
    "position": {
      "x": 136,
      "y": 670,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 293,
    "py\/object": "star.Star"
  },
  {
    "name": "294",
    "position": {
      "x": -341,
      "y": 671,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 294,
    "py\/object": "star.Star"
  },
  {
    "name": "295",
    "position": {
      "x": -435,
      "y": 678,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 295,
    "py\/object": "star.Star"
  },
  {
    "name": "296",
    "position": {
      "x": -221,
      "y": 684,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 296,
    "py\/object": "star.Star"
  },
  {
    "name": "297",
    "position": {
      "x": -1848,
      "y": 683,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 297,
    "py\/object": "star.Star"
  },
  {
    "name": "298",
    "position": {
      "x": 1169,
      "y": 684,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 298,
    "py\/object": "star.Star"
  },
  {
    "name": "299",
    "position": {
      "x": 450,
      "y": 688,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 299,
    "py\/object": "star.Star"
  },
  {
    "name": "300",
    "position": {
      "x": -1520,
      "y": 695,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 300,
    "py\/object": "star.Star"
  },
  {
    "name": "301",
    "position": {
      "x": 1962,
      "y": 701,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 301,
    "py\/object": "star.Star"
  },
  {
    "name": "302",
    "position": {
      "x": 352,
      "y": 715,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 302,
    "py\/object": "star.Star"
  },
  {
    "name": "303",
    "position": {
      "x": 1734,
      "y": 719,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 303,
    "py\/object": "star.Star"
  },
  {
    "name": "304",
    "position": {
      "x": 714,
      "y": 726,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 304,
    "py\/object": "star.Star"
  },
  {
    "name": "305",
    "position": {
      "x": 191,
      "y": 735,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 305,
    "py\/object": "star.Star"
  },
  {
    "name": "306",
    "position": {
      "x": -339,
      "y": 736,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 306,
    "py\/object": "star.Star"
  },
  {
    "name": "307",
    "position": {
      "x": -892,
      "y": 748,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 307,
    "py\/object": "star.Star"
  },
  {
    "name": "308",
    "position": {
      "x": 1761,
      "y": 761,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 308,
    "py\/object": "star.Star"
  },
  {
    "name": "309",
    "position": {
      "x": 266,
      "y": 780,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 309,
    "py\/object": "star.Star"
  },
  {
    "name": "310",
    "position": {
      "x": 2044,
      "y": 782,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 310,
    "py\/object": "star.Star"
  },
  {
    "name": "311",
    "position": {
      "x": -2425,
      "y": 788,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 311,
    "py\/object": "star.Star"
  },
  {
    "name": "312",
    "position": {
      "x": 1291,
      "y": 788,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 312,
    "py\/object": "star.Star"
  },
  {
    "name": "313",
    "position": {
      "x": 1640,
      "y": 790,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 313,
    "py\/object": "star.Star"
  },
  {
    "name": "314",
    "position": {
      "x": 2313,
      "y": 795,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 314,
    "py\/object": "star.Star"
  },
  {
    "name": "315",
    "position": {
      "x": -310,
      "y": 803,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 315,
    "py\/object": "star.Star"
  },
  {
    "name": "316",
    "position": {
      "x": 1058,
      "y": 810,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 316,
    "py\/object": "star.Star"
  },
  {
    "name": "317",
    "position": {
      "x": 389,
      "y": 813,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 317,
    "py\/object": "star.Star"
  },
  {
    "name": "318",
    "position": {
      "x": -790,
      "y": 814,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 318,
    "py\/object": "star.Star"
  },
  {
    "name": "319",
    "position": {
      "x": 1827,
      "y": 816,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 319,
    "py\/object": "star.Star"
  },
  {
    "name": "320",
    "position": {
      "x": -144,
      "y": 824,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 320,
    "py\/object": "star.Star"
  },
  {
    "name": "321",
    "position": {
      "x": -1175,
      "y": 831,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 321,
    "py\/object": "star.Star"
  },
  {
    "name": "322",
    "position": {
      "x": -2135,
      "y": 833,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 322,
    "py\/object": "star.Star"
  },
  {
    "name": "323",
    "position": {
      "x": 1898,
      "y": 843,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 323,
    "py\/object": "star.Star"
  },
  {
    "name": "324",
    "position": {
      "x": -558,
      "y": 844,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 324,
    "py\/object": "star.Star"
  },
  {
    "name": "325",
    "position": {
      "x": 1737,
      "y": 860,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 325,
    "py\/object": "star.Star"
  },
  {
    "name": "326",
    "position": {
      "x": 902,
      "y": 862,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 326,
    "py\/object": "star.Star"
  },
  {
    "name": "327",
    "position": {
      "x": 653,
      "y": 859,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 327,
    "py\/object": "star.Star"
  },
  {
    "name": "328",
    "position": {
      "x": -289,
      "y": 866,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 328,
    "py\/object": "star.Star"
  },
  {
    "name": "329",
    "position": {
      "x": 1780,
      "y": 867,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 329,
    "py\/object": "star.Star"
  },
  {
    "name": "330",
    "position": {
      "x": 1564,
      "y": 883,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 330,
    "py\/object": "star.Star"
  },
  {
    "name": "331",
    "position": {
      "x": -267,
      "y": 886,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 331,
    "py\/object": "star.Star"
  },
  {
    "name": "332",
    "position": {
      "x": 1974,
      "y": 887,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 332,
    "py\/object": "star.Star"
  },
  {
    "name": "333",
    "position": {
      "x": -770,
      "y": 898,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 333,
    "py\/object": "star.Star"
  },
  {
    "name": "334",
    "position": {
      "x": -162,
      "y": 899,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 334,
    "py\/object": "star.Star"
  },
  {
    "name": "335",
    "position": {
      "x": -63,
      "y": 900,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 335,
    "py\/object": "star.Star"
  },
  {
    "name": "336",
    "position": {
      "x": -38,
      "y": 907,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 336,
    "py\/object": "star.Star"
  },
  {
    "name": "337",
    "position": {
      "x": 1660,
      "y": 932,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 337,
    "py\/object": "star.Star"
  },
  {
    "name": "338",
    "position": {
      "x": -1507,
      "y": 941,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 338,
    "py\/object": "star.Star"
  },
  {
    "name": "339",
    "position": {
      "x": -775,
      "y": 943,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 339,
    "py\/object": "star.Star"
  },
  {
    "name": "340",
    "position": {
      "x": 1000,
      "y": 948,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 340,
    "py\/object": "star.Star"
  },
  {
    "name": "341",
    "position": {
      "x": -534,
      "y": 957,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 341,
    "py\/object": "star.Star"
  },
  {
    "name": "342",
    "position": {
      "x": 66,
      "y": 961,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 342,
    "py\/object": "star.Star"
  },
  {
    "name": "343",
    "position": {
      "x": -235,
      "y": 967,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 343,
    "py\/object": "star.Star"
  },
  {
    "name": "344",
    "position": {
      "x": -220,
      "y": 966,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 344,
    "py\/object": "star.Star"
  },
  {
    "name": "345",
    "position": {
      "x": -1900,
      "y": 983,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 345,
    "py\/object": "star.Star"
  },
  {
    "name": "346",
    "position": {
      "x": -2522,
      "y": 987,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 346,
    "py\/object": "star.Star"
  },
  {
    "name": "347",
    "position": {
      "x": 406,
      "y": 989,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 347,
    "py\/object": "star.Star"
  },
  {
    "name": "348",
    "position": {
      "x": 1754,
      "y": 995,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 348,
    "py\/object": "star.Star"
  },
  {
    "name": "349",
    "position": {
      "x": -879,
      "y": 1000,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 349,
    "py\/object": "star.Star"
  },
  {
    "name": "350",
    "position": {
      "x": 2231,
      "y": 1008,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 350,
    "py\/object": "star.Star"
  },
  {
    "name": "351",
    "position": {
      "x": 2024,
      "y": 1006,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 351,
    "py\/object": "star.Star"
  },
  {
    "name": "352",
    "position": {
      "x": 569,
      "y": 1009,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 352,
    "py\/object": "star.Star"
  },
  {
    "name": "353",
    "position": {
      "x": -351,
      "y": 1006,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 353,
    "py\/object": "star.Star"
  },
  {
    "name": "354",
    "position": {
      "x": -1812,
      "y": 1010,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 354,
    "py\/object": "star.Star"
  },
  {
    "name": "355",
    "position": {
      "x": -726,
      "y": 1020,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 355,
    "py\/object": "star.Star"
  },
  {
    "name": "356",
    "position": {
      "x": 2104,
      "y": 1024,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 356,
    "py\/object": "star.Star"
  },
  {
    "name": "357",
    "position": {
      "x": -159,
      "y": 1041,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 357,
    "py\/object": "star.Star"
  },
  {
    "name": "358",
    "position": {
      "x": 1808,
      "y": 1048,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 358,
    "py\/object": "star.Star"
  },
  {
    "name": "359",
    "position": {
      "x": -1033,
      "y": 1049,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 359,
    "py\/object": "star.Star"
  },
  {
    "name": "360",
    "position": {
      "x": -321,
      "y": 1050,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 360,
    "py\/object": "star.Star"
  },
  {
    "name": "361",
    "position": {
      "x": 1370,
      "y": 1056,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 361,
    "py\/object": "star.Star"
  },
  {
    "name": "362",
    "position": {
      "x": -615,
      "y": 1056,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 362,
    "py\/object": "star.Star"
  },
  {
    "name": "363",
    "position": {
      "x": -479,
      "y": 1063,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 363,
    "py\/object": "star.Star"
  },
  {
    "name": "364",
    "position": {
      "x": -1092,
      "y": 1067,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 364,
    "py\/object": "star.Star"
  },
  {
    "name": "365",
    "position": {
      "x": -386,
      "y": 1074,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 365,
    "py\/object": "star.Star"
  },
  {
    "name": "366",
    "position": {
      "x": 772,
      "y": 1075,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 366,
    "py\/object": "star.Star"
  },
  {
    "name": "367",
    "position": {
      "x": 1485,
      "y": 1074,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 367,
    "py\/object": "star.Star"
  },
  {
    "name": "368",
    "position": {
      "x": -2281,
      "y": 1080,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 368,
    "py\/object": "star.Star"
  },
  {
    "name": "369",
    "position": {
      "x": -683,
      "y": 1081,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 369,
    "py\/object": "star.Star"
  },
  {
    "name": "370",
    "position": {
      "x": -586,
      "y": 1083,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 370,
    "py\/object": "star.Star"
  },
  {
    "name": "371",
    "position": {
      "x": 1542,
      "y": 1089,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 371,
    "py\/object": "star.Star"
  },
  {
    "name": "372",
    "position": {
      "x": 2307,
      "y": 1088,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 372,
    "py\/object": "star.Star"
  },
  {
    "name": "373",
    "position": {
      "x": -1458,
      "y": 1092,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 373,
    "py\/object": "star.Star"
  },
  {
    "name": "374",
    "position": {
      "x": -1902,
      "y": 1100,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 374,
    "py\/object": "star.Star"
  },
  {
    "name": "375",
    "position": {
      "x": 309,
      "y": 1098,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 375,
    "py\/object": "star.Star"
  },
  {
    "name": "376",
    "position": {
      "x": -1325,
      "y": 1101,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 376,
    "py\/object": "star.Star"
  },
  {
    "name": "377",
    "position": {
      "x": 1157,
      "y": 1111,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 377,
    "py\/object": "star.Star"
  },
  {
    "name": "378",
    "position": {
      "x": -852,
      "y": 1109,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 378,
    "py\/object": "star.Star"
  },
  {
    "name": "379",
    "position": {
      "x": 1087,
      "y": 1113,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 379,
    "py\/object": "star.Star"
  },
  {
    "name": "380",
    "position": {
      "x": 1296,
      "y": 1121,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 380,
    "py\/object": "star.Star"
  },
  {
    "name": "381",
    "position": {
      "x": 2169,
      "y": 1121,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 381,
    "py\/object": "star.Star"
  },
  {
    "name": "382",
    "position": {
      "x": -334,
      "y": 1122,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 382,
    "py\/object": "star.Star"
  },
  {
    "name": "383",
    "position": {
      "x": -1399,
      "y": 1126,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 383,
    "py\/object": "star.Star"
  },
  {
    "name": "384",
    "position": {
      "x": -1503,
      "y": 1132,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 384,
    "py\/object": "star.Star"
  },
  {
    "name": "385",
    "position": {
      "x": 1573,
      "y": 1136,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 385,
    "py\/object": "star.Star"
  },
  {
    "name": "386",
    "position": {
      "x": -925,
      "y": 1138,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 386,
    "py\/object": "star.Star"
  },
  {
    "name": "387",
    "position": {
      "x": -1640,
      "y": 1140,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 387,
    "py\/object": "star.Star"
  },
  {
    "name": "388",
    "position": {
      "x": -850,
      "y": 1155,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 388,
    "py\/object": "star.Star"
  },
  {
    "name": "389",
    "position": {
      "x": -652,
      "y": 1157,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 389,
    "py\/object": "star.Star"
  },
  {
    "name": "390",
    "position": {
      "x": -302,
      "y": 1190,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 390,
    "py\/object": "star.Star"
  },
  {
    "name": "391",
    "position": {
      "x": 558,
      "y": 1194,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 391,
    "py\/object": "star.Star"
  },
  {
    "name": "392",
    "position": {
      "x": -533,
      "y": 1192,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 392,
    "py\/object": "star.Star"
  },
  {
    "name": "393",
    "position": {
      "x": -1360,
      "y": 1192,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 393,
    "py\/object": "star.Star"
  },
  {
    "name": "394",
    "position": {
      "x": 306,
      "y": 1195,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 394,
    "py\/object": "star.Star"
  },
  {
    "name": "395",
    "position": {
      "x": 53,
      "y": 1196,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 395,
    "py\/object": "star.Star"
  },
  {
    "name": "396",
    "position": {
      "x": 1153,
      "y": 1198,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 396,
    "py\/object": "star.Star"
  },
  {
    "name": "397",
    "position": {
      "x": -755,
      "y": 1202,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 397,
    "py\/object": "star.Star"
  },
  {
    "name": "398",
    "position": {
      "x": -1497,
      "y": 1209,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 398,
    "py\/object": "star.Star"
  },
  {
    "name": "399",
    "position": {
      "x": -1582,
      "y": 1213,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 399,
    "py\/object": "star.Star"
  },
  {
    "name": "400",
    "position": {
      "x": -369,
      "y": 1216,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 400,
    "py\/object": "star.Star"
  },
  {
    "name": "401",
    "position": {
      "x": -1270,
      "y": 1221,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 401,
    "py\/object": "star.Star"
  },
  {
    "name": "402",
    "position": {
      "x": -527,
      "y": 1219,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 402,
    "py\/object": "star.Star"
  },
  {
    "name": "403",
    "position": {
      "x": -1714,
      "y": 1225,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 403,
    "py\/object": "star.Star"
  },
  {
    "name": "404",
    "position": {
      "x": -1417,
      "y": 1237,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 404,
    "py\/object": "star.Star"
  },
  {
    "name": "405",
    "position": {
      "x": 466,
      "y": 1262,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 405,
    "py\/object": "star.Star"
  },
  {
    "name": "406",
    "position": {
      "x": 757,
      "y": 1263,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 406,
    "py\/object": "star.Star"
  },
  {
    "name": "407",
    "position": {
      "x": -475,
      "y": 1267,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 407,
    "py\/object": "star.Star"
  },
  {
    "name": "408",
    "position": {
      "x": 1196,
      "y": 1270,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 408,
    "py\/object": "star.Star"
  },
  {
    "name": "409",
    "position": {
      "x": -1,
      "y": 1272,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 409,
    "py\/object": "star.Star"
  },
  {
    "name": "410",
    "position": {
      "x": -1555,
      "y": 1279,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 410,
    "py\/object": "star.Star"
  },
  {
    "name": "411",
    "position": {
      "x": 1593,
      "y": 1283,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 411,
    "py\/object": "star.Star"
  },
  {
    "name": "412",
    "position": {
      "x": -19,
      "y": 1293,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 412,
    "py\/object": "star.Star"
  },
  {
    "name": "413",
    "position": {
      "x": -1547,
      "y": 1304,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 413,
    "py\/object": "star.Star"
  },
  {
    "name": "414",
    "position": {
      "x": -960,
      "y": 1306,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 414,
    "py\/object": "star.Star"
  },
  {
    "name": "415",
    "position": {
      "x": -1431,
      "y": 1308,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 415,
    "py\/object": "star.Star"
  },
  {
    "name": "416",
    "position": {
      "x": -379,
      "y": 1316,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 416,
    "py\/object": "star.Star"
  },
  {
    "name": "417",
    "position": {
      "x": 1830,
      "y": 1315,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 417,
    "py\/object": "star.Star"
  },
  {
    "name": "418",
    "position": {
      "x": 1389,
      "y": 1320,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 418,
    "py\/object": "star.Star"
  },
  {
    "name": "419",
    "position": {
      "x": -1710,
      "y": 1323,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 419,
    "py\/object": "star.Star"
  },
  {
    "name": "420",
    "position": {
      "x": -1395,
      "y": 1323,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 420,
    "py\/object": "star.Star"
  },
  {
    "name": "421",
    "position": {
      "x": -124,
      "y": 1329,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 421,
    "py\/object": "star.Star"
  },
  {
    "name": "422",
    "position": {
      "x": -652,
      "y": 1330,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 422,
    "py\/object": "star.Star"
  },
  {
    "name": "423",
    "position": {
      "x": -287,
      "y": 1333,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 423,
    "py\/object": "star.Star"
  },
  {
    "name": "424",
    "position": {
      "x": -1314,
      "y": 1334,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 424,
    "py\/object": "star.Star"
  },
  {
    "name": "425",
    "position": {
      "x": 1459,
      "y": 1342,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 425,
    "py\/object": "star.Star"
  },
  {
    "name": "426",
    "position": {
      "x": -1590,
      "y": 1345,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 426,
    "py\/object": "star.Star"
  },
  {
    "name": "427",
    "position": {
      "x": 794,
      "y": 1358,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 427,
    "py\/object": "star.Star"
  },
  {
    "name": "428",
    "position": {
      "x": -980,
      "y": 1359,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 428,
    "py\/object": "star.Star"
  },
  {
    "name": "429",
    "position": {
      "x": 1760,
      "y": 1363,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 429,
    "py\/object": "star.Star"
  },
  {
    "name": "430",
    "position": {
      "x": -65,
      "y": 1376,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 430,
    "py\/object": "star.Star"
  },
  {
    "name": "431",
    "position": {
      "x": -1666,
      "y": 1374,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 431,
    "py\/object": "star.Star"
  },
  {
    "name": "432",
    "position": {
      "x": 542,
      "y": 1377,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 432,
    "py\/object": "star.Star"
  },
  {
    "name": "433",
    "position": {
      "x": 1155,
      "y": 1381,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 433,
    "py\/object": "star.Star"
  },
  {
    "name": "434",
    "position": {
      "x": 268,
      "y": 1389,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 434,
    "py\/object": "star.Star"
  },
  {
    "name": "435",
    "position": {
      "x": -1498,
      "y": 1397,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 435,
    "py\/object": "star.Star"
  },
  {
    "name": "436",
    "position": {
      "x": -865,
      "y": 1402,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 436,
    "py\/object": "star.Star"
  },
  {
    "name": "437",
    "position": {
      "x": -1529,
      "y": 1408,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 437,
    "py\/object": "star.Star"
  },
  {
    "name": "438",
    "position": {
      "x": -1316,
      "y": 1416,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 438,
    "py\/object": "star.Star"
  },
  {
    "name": "439",
    "position": {
      "x": 2168,
      "y": 1422,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 439,
    "py\/object": "star.Star"
  },
  {
    "name": "440",
    "position": {
      "x": 1285,
      "y": 1423,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 440,
    "py\/object": "star.Star"
  },
  {
    "name": "441",
    "position": {
      "x": 2010,
      "y": 1423,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 441,
    "py\/object": "star.Star"
  },
  {
    "name": "442",
    "position": {
      "x": -400,
      "y": 1426,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 442,
    "py\/object": "star.Star"
  },
  {
    "name": "443",
    "position": {
      "x": 802,
      "y": 1427,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 443,
    "py\/object": "star.Star"
  },
  {
    "name": "444",
    "position": {
      "x": -350,
      "y": 1432,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 444,
    "py\/object": "star.Star"
  },
  {
    "name": "445",
    "position": {
      "x": 63,
      "y": 1442,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 445,
    "py\/object": "star.Star"
  },
  {
    "name": "446",
    "position": {
      "x": -447,
      "y": 1452,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 446,
    "py\/object": "star.Star"
  },
  {
    "name": "447",
    "position": {
      "x": 558,
      "y": 1455,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 447,
    "py\/object": "star.Star"
  },
  {
    "name": "448",
    "position": {
      "x": -291,
      "y": 1461,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 448,
    "py\/object": "star.Star"
  },
  {
    "name": "449",
    "position": {
      "x": -222,
      "y": 1467,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 449,
    "py\/object": "star.Star"
  },
  {
    "name": "450",
    "position": {
      "x": -154,
      "y": 1472,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 450,
    "py\/object": "star.Star"
  },
  {
    "name": "451",
    "position": {
      "x": -39,
      "y": 1476,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 451,
    "py\/object": "star.Star"
  },
  {
    "name": "452",
    "position": {
      "x": 325,
      "y": 1475,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 452,
    "py\/object": "star.Star"
  },
  {
    "name": "453",
    "position": {
      "x": -927,
      "y": 1486,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 453,
    "py\/object": "star.Star"
  },
  {
    "name": "454",
    "position": {
      "x": -967,
      "y": 1490,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 454,
    "py\/object": "star.Star"
  },
  {
    "name": "455",
    "position": {
      "x": -1786,
      "y": 1495,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 455,
    "py\/object": "star.Star"
  },
  {
    "name": "456",
    "position": {
      "x": -388,
      "y": 1517,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 456,
    "py\/object": "star.Star"
  },
  {
    "name": "457",
    "position": {
      "x": 952,
      "y": 1519,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 457,
    "py\/object": "star.Star"
  },
  {
    "name": "458",
    "position": {
      "x": -1158,
      "y": 1519,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 458,
    "py\/object": "star.Star"
  },
  {
    "name": "459",
    "position": {
      "x": -815,
      "y": 1532,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 459,
    "py\/object": "star.Star"
  },
  {
    "name": "460",
    "position": {
      "x": -1075,
      "y": 1538,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 460,
    "py\/object": "star.Star"
  },
  {
    "name": "461",
    "position": {
      "x": -1003,
      "y": 1551,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 461,
    "py\/object": "star.Star"
  },
  {
    "name": "462",
    "position": {
      "x": 1842,
      "y": 1552,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 462,
    "py\/object": "star.Star"
  },
  {
    "name": "463",
    "position": {
      "x": 1405,
      "y": 1553,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 463,
    "py\/object": "star.Star"
  },
  {
    "name": "464",
    "position": {
      "x": -377,
      "y": 1555,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 464,
    "py\/object": "star.Star"
  },
  {
    "name": "465",
    "position": {
      "x": 1452,
      "y": 1559,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 465,
    "py\/object": "star.Star"
  },
  {
    "name": "466",
    "position": {
      "x": 321,
      "y": 1569,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 466,
    "py\/object": "star.Star"
  },
  {
    "name": "467",
    "position": {
      "x": 303,
      "y": 1571,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 467,
    "py\/object": "star.Star"
  },
  {
    "name": "468",
    "position": {
      "x": 1257,
      "y": 1575,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 468,
    "py\/object": "star.Star"
  },
  {
    "name": "469",
    "position": {
      "x": -334,
      "y": 1586,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 469,
    "py\/object": "star.Star"
  },
  {
    "name": "470",
    "position": {
      "x": -925,
      "y": 1587,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 470,
    "py\/object": "star.Star"
  },
  {
    "name": "471",
    "position": {
      "x": -5,
      "y": 1589,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 471,
    "py\/object": "star.Star"
  },
  {
    "name": "472",
    "position": {
      "x": -58,
      "y": 1596,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 472,
    "py\/object": "star.Star"
  },
  {
    "name": "473",
    "position": {
      "x": 1158,
      "y": 1599,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 473,
    "py\/object": "star.Star"
  },
  {
    "name": "474",
    "position": {
      "x": 1096,
      "y": 1603,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 474,
    "py\/object": "star.Star"
  },
  {
    "name": "475",
    "position": {
      "x": -887,
      "y": 1623,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 475,
    "py\/object": "star.Star"
  },
  {
    "name": "476",
    "position": {
      "x": -402,
      "y": 1626,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 476,
    "py\/object": "star.Star"
  },
  {
    "name": "477",
    "position": {
      "x": -1194,
      "y": 1631,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 477,
    "py\/object": "star.Star"
  },
  {
    "name": "478",
    "position": {
      "x": 53,
      "y": 1637,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 478,
    "py\/object": "star.Star"
  },
  {
    "name": "479",
    "position": {
      "x": 126,
      "y": 1638,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 479,
    "py\/object": "star.Star"
  },
  {
    "name": "480",
    "position": {
      "x": 1348,
      "y": 1641,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 480,
    "py\/object": "star.Star"
  },
  {
    "name": "481",
    "position": {
      "x": -285,
      "y": 1646,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 481,
    "py\/object": "star.Star"
  },
  {
    "name": "482",
    "position": {
      "x": 1520,
      "y": 1649,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 482,
    "py\/object": "star.Star"
  },
  {
    "name": "483",
    "position": {
      "x": 699,
      "y": 1660,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 483,
    "py\/object": "star.Star"
  },
  {
    "name": "484",
    "position": {
      "x": 832,
      "y": 1658,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 484,
    "py\/object": "star.Star"
  },
  {
    "name": "485",
    "position": {
      "x": -13,
      "y": 1662,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 485,
    "py\/object": "star.Star"
  },
  {
    "name": "486",
    "position": {
      "x": -1349,
      "y": 1663,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 486,
    "py\/object": "star.Star"
  },
  {
    "name": "487",
    "position": {
      "x": -323,
      "y": 1673,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 487,
    "py\/object": "star.Star"
  },
  {
    "name": "488",
    "position": {
      "x": -415,
      "y": 1683,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 488,
    "py\/object": "star.Star"
  },
  {
    "name": "489",
    "position": {
      "x": -1829,
      "y": 1684,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 489,
    "py\/object": "star.Star"
  },
  {
    "name": "490",
    "position": {
      "x": -1452,
      "y": 1686,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 490,
    "py\/object": "star.Star"
  },
  {
    "name": "491",
    "position": {
      "x": -973,
      "y": 1693,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 491,
    "py\/object": "star.Star"
  },
  {
    "name": "492",
    "position": {
      "x": -1101,
      "y": 1696,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 492,
    "py\/object": "star.Star"
  },
  {
    "name": "493",
    "position": {
      "x": 951,
      "y": 1702,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 493,
    "py\/object": "star.Star"
  },
  {
    "name": "494",
    "position": {
      "x": -806,
      "y": 1711,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 494,
    "py\/object": "star.Star"
  },
  {
    "name": "495",
    "position": {
      "x": 1853,
      "y": 1715,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 495,
    "py\/object": "star.Star"
  },
  {
    "name": "496",
    "position": {
      "x": -600,
      "y": 1723,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 496,
    "py\/object": "star.Star"
  },
  {
    "name": "497",
    "position": {
      "x": -1727,
      "y": 1727,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 497,
    "py\/object": "star.Star"
  },
  {
    "name": "498",
    "position": {
      "x": -1070,
      "y": 1731,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 498,
    "py\/object": "star.Star"
  },
  {
    "name": "499",
    "position": {
      "x": -482,
      "y": 1747,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 499,
    "py\/object": "star.Star"
  },
  {
    "name": "500",
    "position": {
      "x": -1534,
      "y": 1751,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 500,
    "py\/object": "star.Star"
  },
  {
    "name": "501",
    "position": {
      "x": -1624,
      "y": 1751,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 501,
    "py\/object": "star.Star"
  },
  {
    "name": "502",
    "position": {
      "x": 1735,
      "y": 1763,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 502,
    "py\/object": "star.Star"
  },
  {
    "name": "503",
    "position": {
      "x": -1643,
      "y": 1765,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 503,
    "py\/object": "star.Star"
  },
  {
    "name": "504",
    "position": {
      "x": 936,
      "y": 1780,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 504,
    "py\/object": "star.Star"
  },
  {
    "name": "505",
    "position": {
      "x": 476,
      "y": 1781,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 505,
    "py\/object": "star.Star"
  },
  {
    "name": "506",
    "position": {
      "x": -513,
      "y": 1783,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 506,
    "py\/object": "star.Star"
  },
  {
    "name": "507",
    "position": {
      "x": 567,
      "y": 1786,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 507,
    "py\/object": "star.Star"
  },
  {
    "name": "508",
    "position": {
      "x": -1689,
      "y": 1807,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 508,
    "py\/object": "star.Star"
  },
  {
    "name": "509",
    "position": {
      "x": 1276,
      "y": 1813,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 509,
    "py\/object": "star.Star"
  },
  {
    "name": "510",
    "position": {
      "x": 296,
      "y": 1813,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 510,
    "py\/object": "star.Star"
  },
  {
    "name": "511",
    "position": {
      "x": -455,
      "y": 1817,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 511,
    "py\/object": "star.Star"
  },
  {
    "name": "512",
    "position": {
      "x": -1604,
      "y": 1816,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 512,
    "py\/object": "star.Star"
  },
  {
    "name": "513",
    "position": {
      "x": 986,
      "y": 1816,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 513,
    "py\/object": "star.Star"
  },
  {
    "name": "514",
    "position": {
      "x": 704,
      "y": 1826,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 514,
    "py\/object": "star.Star"
  },
  {
    "name": "515",
    "position": {
      "x": -1670,
      "y": 1828,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 515,
    "py\/object": "star.Star"
  },
  {
    "name": "516",
    "position": {
      "x": 70,
      "y": 1829,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 516,
    "py\/object": "star.Star"
  },
  {
    "name": "517",
    "position": {
      "x": -1556,
      "y": 1831,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 517,
    "py\/object": "star.Star"
  },
  {
    "name": "518",
    "position": {
      "x": -1233,
      "y": 1835,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 518,
    "py\/object": "star.Star"
  },
  {
    "name": "519",
    "position": {
      "x": 1248,
      "y": 1857,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 519,
    "py\/object": "star.Star"
  },
  {
    "name": "520",
    "position": {
      "x": -153,
      "y": 1872,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 520,
    "py\/object": "star.Star"
  },
  {
    "name": "521",
    "position": {
      "x": -1693,
      "y": 1885,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 521,
    "py\/object": "star.Star"
  },
  {
    "name": "522",
    "position": {
      "x": -679,
      "y": 1892,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 522,
    "py\/object": "star.Star"
  },
  {
    "name": "523",
    "position": {
      "x": -1835,
      "y": 1899,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 523,
    "py\/object": "star.Star"
  },
  {
    "name": "524",
    "position": {
      "x": -587,
      "y": 1901,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 524,
    "py\/object": "star.Star"
  },
  {
    "name": "525",
    "position": {
      "x": 806,
      "y": 1904,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 525,
    "py\/object": "star.Star"
  },
  {
    "name": "526",
    "position": {
      "x": 5,
      "y": 1906,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 526,
    "py\/object": "star.Star"
  },
  {
    "name": "527",
    "position": {
      "x": 1606,
      "y": 1912,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 527,
    "py\/object": "star.Star"
  },
  {
    "name": "528",
    "position": {
      "x": -1619,
      "y": 1923,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 528,
    "py\/object": "star.Star"
  },
  {
    "name": "529",
    "position": {
      "x": 472,
      "y": 1929,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 529,
    "py\/object": "star.Star"
  },
  {
    "name": "530",
    "position": {
      "x": -1574,
      "y": 1929,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 530,
    "py\/object": "star.Star"
  },
  {
    "name": "531",
    "position": {
      "x": 668,
      "y": 1934,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 531,
    "py\/object": "star.Star"
  },
  {
    "name": "532",
    "position": {
      "x": -1654,
      "y": 1932,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 532,
    "py\/object": "star.Star"
  },
  {
    "name": "533",
    "position": {
      "x": 881,
      "y": 1942,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 533,
    "py\/object": "star.Star"
  },
  {
    "name": "534",
    "position": {
      "x": 391,
      "y": 1940,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 534,
    "py\/object": "star.Star"
  },
  {
    "name": "535",
    "position": {
      "x": -1673,
      "y": 1951,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 535,
    "py\/object": "star.Star"
  },
  {
    "name": "536",
    "position": {
      "x": -253,
      "y": 1960,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 536,
    "py\/object": "star.Star"
  },
  {
    "name": "537",
    "position": {
      "x": -1086,
      "y": 1962,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 537,
    "py\/object": "star.Star"
  },
  {
    "name": "538",
    "position": {
      "x": 309,
      "y": 1961,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 538,
    "py\/object": "star.Star"
  },
  {
    "name": "539",
    "position": {
      "x": -1307,
      "y": 1962,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 539,
    "py\/object": "star.Star"
  },
  {
    "name": "540",
    "position": {
      "x": 1363,
      "y": 1970,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 540,
    "py\/object": "star.Star"
  },
  {
    "name": "541",
    "position": {
      "x": 1773,
      "y": 1975,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 541,
    "py\/object": "star.Star"
  },
  {
    "name": "542",
    "position": {
      "x": 420,
      "y": 1977,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 542,
    "py\/object": "star.Star"
  },
  {
    "name": "543",
    "position": {
      "x": -802,
      "y": 1979,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 543,
    "py\/object": "star.Star"
  },
  {
    "name": "544",
    "position": {
      "x": -703,
      "y": 1981,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 544,
    "py\/object": "star.Star"
  },
  {
    "name": "545",
    "position": {
      "x": -796,
      "y": 1997,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 545,
    "py\/object": "star.Star"
  },
  {
    "name": "546",
    "position": {
      "x": 658,
      "y": 2001,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 546,
    "py\/object": "star.Star"
  },
  {
    "name": "547",
    "position": {
      "x": -900,
      "y": 2002,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 547,
    "py\/object": "star.Star"
  },
  {
    "name": "548",
    "position": {
      "x": 468,
      "y": 2011,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 548,
    "py\/object": "star.Star"
  },
  {
    "name": "549",
    "position": {
      "x": 352,
      "y": 2011,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 549,
    "py\/object": "star.Star"
  },
  {
    "name": "550",
    "position": {
      "x": -1020,
      "y": 2010,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 550,
    "py\/object": "star.Star"
  },
  {
    "name": "551",
    "position": {
      "x": 1182,
      "y": 2015,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 551,
    "py\/object": "star.Star"
  },
  {
    "name": "552",
    "position": {
      "x": 428,
      "y": 2034,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 552,
    "py\/object": "star.Star"
  },
  {
    "name": "553",
    "position": {
      "x": 1486,
      "y": 2036,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 553,
    "py\/object": "star.Star"
  },
  {
    "name": "554",
    "position": {
      "x": 315,
      "y": 2043,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 554,
    "py\/object": "star.Star"
  },
  {
    "name": "555",
    "position": {
      "x": -761,
      "y": 2046,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 555,
    "py\/object": "star.Star"
  },
  {
    "name": "556",
    "position": {
      "x": 885,
      "y": 2048,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 556,
    "py\/object": "star.Star"
  },
  {
    "name": "557",
    "position": {
      "x": -1002,
      "y": 2050,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 557,
    "py\/object": "star.Star"
  },
  {
    "name": "558",
    "position": {
      "x": 256,
      "y": 2055,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 558,
    "py\/object": "star.Star"
  },
  {
    "name": "559",
    "position": {
      "x": 646,
      "y": 2067,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 559,
    "py\/object": "star.Star"
  },
  {
    "name": "560",
    "position": {
      "x": 458,
      "y": 2071,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 560,
    "py\/object": "star.Star"
  },
  {
    "name": "561",
    "position": {
      "x": 1388,
      "y": 2073,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 561,
    "py\/object": "star.Star"
  },
  {
    "name": "562",
    "position": {
      "x": -394,
      "y": 2080,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 562,
    "py\/object": "star.Star"
  },
  {
    "name": "563",
    "position": {
      "x": 806,
      "y": 2085,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 563,
    "py\/object": "star.Star"
  },
  {
    "name": "564",
    "position": {
      "x": -645,
      "y": 2090,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 564,
    "py\/object": "star.Star"
  },
  {
    "name": "565",
    "position": {
      "x": -1380,
      "y": 2093,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 565,
    "py\/object": "star.Star"
  },
  {
    "name": "566",
    "position": {
      "x": -160,
      "y": 2099,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 566,
    "py\/object": "star.Star"
  },
  {
    "name": "567",
    "position": {
      "x": 373,
      "y": 2094,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 567,
    "py\/object": "star.Star"
  },
  {
    "name": "568",
    "position": {
      "x": -977,
      "y": 2103,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 568,
    "py\/object": "star.Star"
  },
  {
    "name": "569",
    "position": {
      "x": -1931,
      "y": 2105,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 569,
    "py\/object": "star.Star"
  },
  {
    "name": "570",
    "position": {
      "x": 528,
      "y": 2105,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 570,
    "py\/object": "star.Star"
  },
  {
    "name": "571",
    "position": {
      "x": -1239,
      "y": 2112,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 571,
    "py\/object": "star.Star"
  },
  {
    "name": "572",
    "position": {
      "x": 639,
      "y": 2117,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 572,
    "py\/object": "star.Star"
  },
  {
    "name": "573",
    "position": {
      "x": -57,
      "y": 2120,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 573,
    "py\/object": "star.Star"
  },
  {
    "name": "574",
    "position": {
      "x": -1314,
      "y": 2126,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 574,
    "py\/object": "star.Star"
  },
  {
    "name": "575",
    "position": {
      "x": -314,
      "y": 2124,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 575,
    "py\/object": "star.Star"
  },
  {
    "name": "576",
    "position": {
      "x": 783,
      "y": 2126,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 576,
    "py\/object": "star.Star"
  },
  {
    "name": "577",
    "position": {
      "x": -547,
      "y": 2131,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 577,
    "py\/object": "star.Star"
  },
  {
    "name": "578",
    "position": {
      "x": 1005,
      "y": 2137,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 578,
    "py\/object": "star.Star"
  },
  {
    "name": "579",
    "position": {
      "x": 296,
      "y": 2138,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 579,
    "py\/object": "star.Star"
  },
  {
    "name": "580",
    "position": {
      "x": -1541,
      "y": 2138,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 580,
    "py\/object": "star.Star"
  },
  {
    "name": "581",
    "position": {
      "x": -988,
      "y": 2139,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 581,
    "py\/object": "star.Star"
  },
  {
    "name": "582",
    "position": {
      "x": 1291,
      "y": 2146,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 582,
    "py\/object": "star.Star"
  },
  {
    "name": "583",
    "position": {
      "x": 755,
      "y": 2146,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 583,
    "py\/object": "star.Star"
  },
  {
    "name": "584",
    "position": {
      "x": 502,
      "y": 2145,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 584,
    "py\/object": "star.Star"
  },
  {
    "name": "585",
    "position": {
      "x": 630,
      "y": 2151,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 585,
    "py\/object": "star.Star"
  },
  {
    "name": "586",
    "position": {
      "x": -758,
      "y": 2150,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 586,
    "py\/object": "star.Star"
  },
  {
    "name": "587",
    "position": {
      "x": -454,
      "y": 2153,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 587,
    "py\/object": "star.Star"
  },
  {
    "name": "588",
    "position": {
      "x": 1169,
      "y": 2152,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 588,
    "py\/object": "star.Star"
  },
  {
    "name": "589",
    "position": {
      "x": -1660,
      "y": 2163,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 589,
    "py\/object": "star.Star"
  },
  {
    "name": "590",
    "position": {
      "x": -983,
      "y": 2175,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 590,
    "py\/object": "star.Star"
  },
  {
    "name": "591",
    "position": {
      "x": 368,
      "y": 2180,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 591,
    "py\/object": "star.Star"
  },
  {
    "name": "592",
    "position": {
      "x": 1014,
      "y": 2178,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 592,
    "py\/object": "star.Star"
  },
  {
    "name": "593",
    "position": {
      "x": -47,
      "y": 2184,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 593,
    "py\/object": "star.Star"
  },
  {
    "name": "594",
    "position": {
      "x": 238,
      "y": 2185,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 594,
    "py\/object": "star.Star"
  },
  {
    "name": "595",
    "position": {
      "x": -1191,
      "y": 2186,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 595,
    "py\/object": "star.Star"
  },
  {
    "name": "596",
    "position": {
      "x": 857,
      "y": 2190,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 596,
    "py\/object": "star.Star"
  },
  {
    "name": "597",
    "position": {
      "x": 291,
      "y": 2197,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 597,
    "py\/object": "star.Star"
  },
  {
    "name": "598",
    "position": {
      "x": 679,
      "y": 2202,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 598,
    "py\/object": "star.Star"
  },
  {
    "name": "599",
    "position": {
      "x": 1248,
      "y": 2207,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 599,
    "py\/object": "star.Star"
  },
  {
    "name": "600",
    "position": {
      "x": 445,
      "y": 2206,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 600,
    "py\/object": "star.Star"
  },
  {
    "name": "601",
    "position": {
      "x": -529,
      "y": 2209,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 601,
    "py\/object": "star.Star"
  },
  {
    "name": "602",
    "position": {
      "x": -791,
      "y": 2214,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 602,
    "py\/object": "star.Star"
  },
  {
    "name": "603",
    "position": {
      "x": -595,
      "y": 2218,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 603,
    "py\/object": "star.Star"
  },
  {
    "name": "604",
    "position": {
      "x": 109,
      "y": 2219,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 604,
    "py\/object": "star.Star"
  },
  {
    "name": "605",
    "position": {
      "x": 738,
      "y": 2221,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 605,
    "py\/object": "star.Star"
  },
  {
    "name": "606",
    "position": {
      "x": 232,
      "y": 2232,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 606,
    "py\/object": "star.Star"
  },
  {
    "name": "607",
    "position": {
      "x": 383,
      "y": 2232,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 607,
    "py\/object": "star.Star"
  },
  {
    "name": "608",
    "position": {
      "x": 1496,
      "y": 2236,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 608,
    "py\/object": "star.Star"
  },
  {
    "name": "609",
    "position": {
      "x": 587,
      "y": 2237,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 609,
    "py\/object": "star.Star"
  },
  {
    "name": "610",
    "position": {
      "x": -440,
      "y": 2238,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 610,
    "py\/object": "star.Star"
  },
  {
    "name": "611",
    "position": {
      "x": 915,
      "y": 2238,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 611,
    "py\/object": "star.Star"
  },
  {
    "name": "612",
    "position": {
      "x": -498,
      "y": 2241,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 612,
    "py\/object": "star.Star"
  },
  {
    "name": "613",
    "position": {
      "x": 812,
      "y": 2248,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 613,
    "py\/object": "star.Star"
  },
  {
    "name": "614",
    "position": {
      "x": 285,
      "y": 2253,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 614,
    "py\/object": "star.Star"
  },
  {
    "name": "615",
    "position": {
      "x": -370,
      "y": 2264,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 615,
    "py\/object": "star.Star"
  },
  {
    "name": "616",
    "position": {
      "x": -704,
      "y": 2266,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 616,
    "py\/object": "star.Star"
  },
  {
    "name": "617",
    "position": {
      "x": -1622,
      "y": 2271,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 617,
    "py\/object": "star.Star"
  },
  {
    "name": "618",
    "position": {
      "x": 492,
      "y": 2274,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 618,
    "py\/object": "star.Star"
  },
  {
    "name": "619",
    "position": {
      "x": 316,
      "y": 2277,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 619,
    "py\/object": "star.Star"
  },
  {
    "name": "620",
    "position": {
      "x": 408,
      "y": 2279,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 620,
    "py\/object": "star.Star"
  },
  {
    "name": "621",
    "position": {
      "x": 1439,
      "y": 2286,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 621,
    "py\/object": "star.Star"
  },
  {
    "name": "622",
    "position": {
      "x": 834,
      "y": 2289,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 622,
    "py\/object": "star.Star"
  },
  {
    "name": "623",
    "position": {
      "x": 671,
      "y": 2289,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 623,
    "py\/object": "star.Star"
  },
  {
    "name": "624",
    "position": {
      "x": 861,
      "y": 2290,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 624,
    "py\/object": "star.Star"
  },
  {
    "name": "625",
    "position": {
      "x": 805,
      "y": 2291,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 625,
    "py\/object": "star.Star"
  },
  {
    "name": "626",
    "position": {
      "x": -856,
      "y": 2291,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 626,
    "py\/object": "star.Star"
  },
  {
    "name": "627",
    "position": {
      "x": 986,
      "y": 2292,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 627,
    "py\/object": "star.Star"
  },
  {
    "name": "628",
    "position": {
      "x": -59,
      "y": 2304,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 628,
    "py\/object": "star.Star"
  },
  {
    "name": "629",
    "position": {
      "x": 1323,
      "y": 2308,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 629,
    "py\/object": "star.Star"
  },
  {
    "name": "630",
    "position": {
      "x": 1631,
      "y": 2314,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 630,
    "py\/object": "star.Star"
  },
  {
    "name": "631",
    "position": {
      "x": -302,
      "y": 2315,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 631,
    "py\/object": "star.Star"
  },
  {
    "name": "632",
    "position": {
      "x": -790,
      "y": 2316,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 632,
    "py\/object": "star.Star"
  },
  {
    "name": "633",
    "position": {
      "x": -382,
      "y": 2319,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 633,
    "py\/object": "star.Star"
  },
  {
    "name": "634",
    "position": {
      "x": -1300,
      "y": 2317,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 634,
    "py\/object": "star.Star"
  },
  {
    "name": "635",
    "position": {
      "x": 378,
      "y": 2323,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 635,
    "py\/object": "star.Star"
  },
  {
    "name": "636",
    "position": {
      "x": 938,
      "y": 2328,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 636,
    "py\/object": "star.Star"
  },
  {
    "name": "637",
    "position": {
      "x": 219,
      "y": 2331,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 637,
    "py\/object": "star.Star"
  },
  {
    "name": "638",
    "position": {
      "x": 771,
      "y": 2333,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 638,
    "py\/object": "star.Star"
  },
  {
    "name": "639",
    "position": {
      "x": 634,
      "y": 2337,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 639,
    "py\/object": "star.Star"
  },
  {
    "name": "640",
    "position": {
      "x": -1106,
      "y": 2336,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 640,
    "py\/object": "star.Star"
  },
  {
    "name": "641",
    "position": {
      "x": -1691,
      "y": 2354,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 641,
    "py\/object": "star.Star"
  },
  {
    "name": "642",
    "position": {
      "x": 1267,
      "y": 2355,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 642,
    "py\/object": "star.Star"
  },
  {
    "name": "643",
    "position": {
      "x": 317,
      "y": 2365,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 643,
    "py\/object": "star.Star"
  },
  {
    "name": "644",
    "position": {
      "x": -1396,
      "y": 2367,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 644,
    "py\/object": "star.Star"
  },
  {
    "name": "645",
    "position": {
      "x": 1761,
      "y": 2365,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 645,
    "py\/object": "star.Star"
  },
  {
    "name": "646",
    "position": {
      "x": 958,
      "y": 2366,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 646,
    "py\/object": "star.Star"
  },
  {
    "name": "647",
    "position": {
      "x": 1520,
      "y": 2370,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 647,
    "py\/object": "star.Star"
  },
  {
    "name": "648",
    "position": {
      "x": -686,
      "y": 2370,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 648,
    "py\/object": "star.Star"
  },
  {
    "name": "649",
    "position": {
      "x": 825,
      "y": 2373,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 649,
    "py\/object": "star.Star"
  },
  {
    "name": "650",
    "position": {
      "x": -1694,
      "y": 2373,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 650,
    "py\/object": "star.Star"
  },
  {
    "name": "651",
    "position": {
      "x": 897,
      "y": 2377,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 651,
    "py\/object": "star.Star"
  },
  {
    "name": "652",
    "position": {
      "x": 728,
      "y": 2379,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 652,
    "py\/object": "star.Star"
  },
  {
    "name": "653",
    "position": {
      "x": -938,
      "y": 2377,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 653,
    "py\/object": "star.Star"
  },
  {
    "name": "654",
    "position": {
      "x": 89,
      "y": 2379,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 654,
    "py\/object": "star.Star"
  },
  {
    "name": "655",
    "position": {
      "x": -747,
      "y": 2383,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 655,
    "py\/object": "star.Star"
  },
  {
    "name": "656",
    "position": {
      "x": 1565,
      "y": 2383,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 656,
    "py\/object": "star.Star"
  },
  {
    "name": "657",
    "position": {
      "x": 1403,
      "y": 2389,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 657,
    "py\/object": "star.Star"
  },
  {
    "name": "658",
    "position": {
      "x": 984,
      "y": 2389,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 658,
    "py\/object": "star.Star"
  },
  {
    "name": "659",
    "position": {
      "x": -808,
      "y": 2390,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 659,
    "py\/object": "star.Star"
  },
  {
    "name": "660",
    "position": {
      "x": -559,
      "y": 2393,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 660,
    "py\/object": "star.Star"
  },
  {
    "name": "661",
    "position": {
      "x": -188,
      "y": 2395,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 661,
    "py\/object": "star.Star"
  },
  {
    "name": "662",
    "position": {
      "x": -306,
      "y": 2397,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 662,
    "py\/object": "star.Star"
  },
  {
    "name": "663",
    "position": {
      "x": -1541,
      "y": 2397,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 663,
    "py\/object": "star.Star"
  },
  {
    "name": "664",
    "position": {
      "x": -77,
      "y": 2403,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 664,
    "py\/object": "star.Star"
  },
  {
    "name": "665",
    "position": {
      "x": -625,
      "y": 2408,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 665,
    "py\/object": "star.Star"
  },
  {
    "name": "666",
    "position": {
      "x": 1025,
      "y": 2415,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 666,
    "py\/object": "star.Star"
  },
  {
    "name": "667",
    "position": {
      "x": -1135,
      "y": 2416,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 667,
    "py\/object": "star.Star"
  },
  {
    "name": "668",
    "position": {
      "x": 730,
      "y": 2419,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 668,
    "py\/object": "star.Star"
  },
  {
    "name": "669",
    "position": {
      "x": 983,
      "y": 2421,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 669,
    "py\/object": "star.Star"
  },
  {
    "name": "670",
    "position": {
      "x": 790,
      "y": 2424,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 670,
    "py\/object": "star.Star"
  },
  {
    "name": "671",
    "position": {
      "x": 1515,
      "y": 2434,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 671,
    "py\/object": "star.Star"
  },
  {
    "name": "672",
    "position": {
      "x": -1211,
      "y": 2435,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 672,
    "py\/object": "star.Star"
  },
  {
    "name": "673",
    "position": {
      "x": 719,
      "y": 2439,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 673,
    "py\/object": "star.Star"
  },
  {
    "name": "674",
    "position": {
      "x": 933,
      "y": 2444,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 674,
    "py\/object": "star.Star"
  },
  {
    "name": "675",
    "position": {
      "x": 353,
      "y": 2443,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 675,
    "py\/object": "star.Star"
  },
  {
    "name": "676",
    "position": {
      "x": 224,
      "y": 2452,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 676,
    "py\/object": "star.Star"
  },
  {
    "name": "677",
    "position": {
      "x": -653,
      "y": 2453,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 677,
    "py\/object": "star.Star"
  },
  {
    "name": "678",
    "position": {
      "x": 1082,
      "y": 2456,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 678,
    "py\/object": "star.Star"
  },
  {
    "name": "679",
    "position": {
      "x": -1330,
      "y": 2454,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 679,
    "py\/object": "star.Star"
  },
  {
    "name": "680",
    "position": {
      "x": -733,
      "y": 2475,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 680,
    "py\/object": "star.Star"
  },
  {
    "name": "681",
    "position": {
      "x": 854,
      "y": 2477,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 681,
    "py\/object": "star.Star"
  },
  {
    "name": "682",
    "position": {
      "x": 315,
      "y": 2479,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 682,
    "py\/object": "star.Star"
  },
  {
    "name": "683",
    "position": {
      "x": 750,
      "y": 2482,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 683,
    "py\/object": "star.Star"
  },
  {
    "name": "684",
    "position": {
      "x": -220,
      "y": 2484,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 684,
    "py\/object": "star.Star"
  },
  {
    "name": "685",
    "position": {
      "x": -969,
      "y": 2489,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 685,
    "py\/object": "star.Star"
  },
  {
    "name": "686",
    "position": {
      "x": 1047,
      "y": 2492,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 686,
    "py\/object": "star.Star"
  },
  {
    "name": "687",
    "position": {
      "x": 1135,
      "y": 2493,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 687,
    "py\/object": "star.Star"
  },
  {
    "name": "688",
    "position": {
      "x": 707,
      "y": 2494,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 688,
    "py\/object": "star.Star"
  },
  {
    "name": "689",
    "position": {
      "x": -1559,
      "y": 2496,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 689,
    "py\/object": "star.Star"
  },
  {
    "name": "690",
    "position": {
      "x": -364,
      "y": 2498,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 690,
    "py\/object": "star.Star"
  },
  {
    "name": "691",
    "position": {
      "x": 1362,
      "y": 2505,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 691,
    "py\/object": "star.Star"
  },
  {
    "name": "692",
    "position": {
      "x": 243,
      "y": 2508,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 692,
    "py\/object": "star.Star"
  },
  {
    "name": "693",
    "position": {
      "x": -489,
      "y": 2510,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 693,
    "py\/object": "star.Star"
  },
  {
    "name": "694",
    "position": {
      "x": -623,
      "y": 2513,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 694,
    "py\/object": "star.Star"
  },
  {
    "name": "695",
    "position": {
      "x": 1266,
      "y": 2517,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 695,
    "py\/object": "star.Star"
  },
  {
    "name": "696",
    "position": {
      "x": 1062,
      "y": 2516,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 696,
    "py\/object": "star.Star"
  },
  {
    "name": "697",
    "position": {
      "x": 1464,
      "y": 2525,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 697,
    "py\/object": "star.Star"
  },
  {
    "name": "698",
    "position": {
      "x": 802,
      "y": 2525,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 698,
    "py\/object": "star.Star"
  },
  {
    "name": "699",
    "position": {
      "x": -408,
      "y": 2528,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 699,
    "py\/object": "star.Star"
  },
  {
    "name": "700",
    "position": {
      "x": -1399,
      "y": 2532,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 700,
    "py\/object": "star.Star"
  },
  {
    "name": "701",
    "position": {
      "x": -1114,
      "y": 2544,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 701,
    "py\/object": "star.Star"
  },
  {
    "name": "702",
    "position": {
      "x": 1566,
      "y": 2544,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 702,
    "py\/object": "star.Star"
  },
  {
    "name": "703",
    "position": {
      "x": -327,
      "y": 2551,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 703,
    "py\/object": "star.Star"
  },
  {
    "name": "704",
    "position": {
      "x": -689,
      "y": 2551,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 704,
    "py\/object": "star.Star"
  },
  {
    "name": "705",
    "position": {
      "x": -44,
      "y": 2553,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 705,
    "py\/object": "star.Star"
  },
  {
    "name": "706",
    "position": {
      "x": 507,
      "y": 2554,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 706,
    "py\/object": "star.Star"
  },
  {
    "name": "707",
    "position": {
      "x": -1489,
      "y": 2556,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 707,
    "py\/object": "star.Star"
  },
  {
    "name": "708",
    "position": {
      "x": 1352,
      "y": 2558,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 708,
    "py\/object": "star.Star"
  },
  {
    "name": "709",
    "position": {
      "x": 1076,
      "y": 2559,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 709,
    "py\/object": "star.Star"
  },
  {
    "name": "710",
    "position": {
      "x": 35,
      "y": 2561,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 710,
    "py\/object": "star.Star"
  },
  {
    "name": "711",
    "position": {
      "x": -1255,
      "y": 2560,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 711,
    "py\/object": "star.Star"
  },
  {
    "name": "712",
    "position": {
      "x": 569,
      "y": 2562,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 712,
    "py\/object": "star.Star"
  },
  {
    "name": "713",
    "position": {
      "x": -478,
      "y": 2563,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 713,
    "py\/object": "star.Star"
  },
  {
    "name": "714",
    "position": {
      "x": -772,
      "y": 2569,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 714,
    "py\/object": "star.Star"
  },
  {
    "name": "715",
    "position": {
      "x": -53,
      "y": 2571,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 715,
    "py\/object": "star.Star"
  },
  {
    "name": "716",
    "position": {
      "x": -1955,
      "y": 2570,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 716,
    "py\/object": "star.Star"
  },
  {
    "name": "717",
    "position": {
      "x": -144,
      "y": 2576,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 717,
    "py\/object": "star.Star"
  },
  {
    "name": "718",
    "position": {
      "x": 993,
      "y": 2576,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 718,
    "py\/object": "star.Star"
  },
  {
    "name": "719",
    "position": {
      "x": 1059,
      "y": 2580,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 719,
    "py\/object": "star.Star"
  },
  {
    "name": "720",
    "position": {
      "x": 22,
      "y": 2583,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 720,
    "py\/object": "star.Star"
  },
  {
    "name": "721",
    "position": {
      "x": -567,
      "y": 2583,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 721,
    "py\/object": "star.Star"
  },
  {
    "name": "722",
    "position": {
      "x": -976,
      "y": 2589,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 722,
    "py\/object": "star.Star"
  },
  {
    "name": "723",
    "position": {
      "x": 851,
      "y": 2591,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 723,
    "py\/object": "star.Star"
  },
  {
    "name": "724",
    "position": {
      "x": -31,
      "y": 2591,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 724,
    "py\/object": "star.Star"
  },
  {
    "name": "725",
    "position": {
      "x": 728,
      "y": 2593,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 725,
    "py\/object": "star.Star"
  },
  {
    "name": "726",
    "position": {
      "x": -1254,
      "y": 2594,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 726,
    "py\/object": "star.Star"
  },
  {
    "name": "727",
    "position": {
      "x": 1627,
      "y": 2596,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 727,
    "py\/object": "star.Star"
  },
  {
    "name": "728",
    "position": {
      "x": 1137,
      "y": 2596,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 728,
    "py\/object": "star.Star"
  },
  {
    "name": "729",
    "position": {
      "x": -71,
      "y": 2598,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 729,
    "py\/object": "star.Star"
  },
  {
    "name": "730",
    "position": {
      "x": -164,
      "y": 2602,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 730,
    "py\/object": "star.Star"
  },
  {
    "name": "731",
    "position": {
      "x": -123,
      "y": 2612,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 731,
    "py\/object": "star.Star"
  },
  {
    "name": "732",
    "position": {
      "x": 1328,
      "y": 2613,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 732,
    "py\/object": "star.Star"
  },
  {
    "name": "733",
    "position": {
      "x": 28,
      "y": 2617,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 733,
    "py\/object": "star.Star"
  },
  {
    "name": "734",
    "position": {
      "x": -9,
      "y": 2611,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 734,
    "py\/object": "star.Star"
  },
  {
    "name": "735",
    "position": {
      "x": 1452,
      "y": 2622,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 735,
    "py\/object": "star.Star"
  },
  {
    "name": "736",
    "position": {
      "x": 1030,
      "y": 2622,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 736,
    "py\/object": "star.Star"
  },
  {
    "name": "737",
    "position": {
      "x": -143,
      "y": 2620,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 737,
    "py\/object": "star.Star"
  },
  {
    "name": "738",
    "position": {
      "x": -247,
      "y": 2623,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 738,
    "py\/object": "star.Star"
  },
  {
    "name": "739",
    "position": {
      "x": -1587,
      "y": 2623,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 739,
    "py\/object": "star.Star"
  },
  {
    "name": "740",
    "position": {
      "x": 1100,
      "y": 2626,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 740,
    "py\/object": "star.Star"
  },
  {
    "name": "741",
    "position": {
      "x": -1469,
      "y": 2626,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 741,
    "py\/object": "star.Star"
  },
  {
    "name": "742",
    "position": {
      "x": -1682,
      "y": 2628,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 742,
    "py\/object": "star.Star"
  },
  {
    "name": "743",
    "position": {
      "x": -587,
      "y": 2628,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 743,
    "py\/object": "star.Star"
  },
  {
    "name": "744",
    "position": {
      "x": -91,
      "y": 2631,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 744,
    "py\/object": "star.Star"
  },
  {
    "name": "745",
    "position": {
      "x": -185,
      "y": 2630,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 745,
    "py\/object": "star.Star"
  },
  {
    "name": "746",
    "position": {
      "x": -1171,
      "y": 2633,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 746,
    "py\/object": "star.Star"
  },
  {
    "name": "747",
    "position": {
      "x": 1234,
      "y": 2637,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 747,
    "py\/object": "star.Star"
  },
  {
    "name": "748",
    "position": {
      "x": -37,
      "y": 2639,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 748,
    "py\/object": "star.Star"
  },
  {
    "name": "749",
    "position": {
      "x": -149,
      "y": 2646,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 749,
    "py\/object": "star.Star"
  },
  {
    "name": "750",
    "position": {
      "x": -1071,
      "y": 2650,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 750,
    "py\/object": "star.Star"
  },
  {
    "name": "751",
    "position": {
      "x": 1191,
      "y": 2652,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 751,
    "py\/object": "star.Star"
  },
  {
    "name": "752",
    "position": {
      "x": -92,
      "y": 2651,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 752,
    "py\/object": "star.Star"
  },
  {
    "name": "753",
    "position": {
      "x": -366,
      "y": 2653,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 753,
    "py\/object": "star.Star"
  },
  {
    "name": "754",
    "position": {
      "x": 26,
      "y": 2651,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 754,
    "py\/object": "star.Star"
  },
  {
    "name": "755",
    "position": {
      "x": -63,
      "y": 2658,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 755,
    "py\/object": "star.Star"
  },
  {
    "name": "756",
    "position": {
      "x": 1554,
      "y": 2663,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 756,
    "py\/object": "star.Star"
  },
  {
    "name": "757",
    "position": {
      "x": -160,
      "y": 2666,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 757,
    "py\/object": "star.Star"
  },
  {
    "name": "758",
    "position": {
      "x": -956,
      "y": 2675,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 758,
    "py\/object": "star.Star"
  },
  {
    "name": "759",
    "position": {
      "x": -1221,
      "y": 2679,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 759,
    "py\/object": "star.Star"
  },
  {
    "name": "760",
    "position": {
      "x": 80,
      "y": 2683,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 760,
    "py\/object": "star.Star"
  },
  {
    "name": "761",
    "position": {
      "x": 1047,
      "y": 2686,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 761,
    "py\/object": "star.Star"
  },
  {
    "name": "762",
    "position": {
      "x": 1318,
      "y": 2686,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 762,
    "py\/object": "star.Star"
  },
  {
    "name": "763",
    "position": {
      "x": -1613,
      "y": 2686,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 763,
    "py\/object": "star.Star"
  },
  {
    "name": "764",
    "position": {
      "x": 620,
      "y": 2688,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 764,
    "py\/object": "star.Star"
  },
  {
    "name": "765",
    "position": {
      "x": -395,
      "y": 2689,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 765,
    "py\/object": "star.Star"
  },
  {
    "name": "766",
    "position": {
      "x": 1540,
      "y": 2690,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 766,
    "py\/object": "star.Star"
  },
  {
    "name": "767",
    "position": {
      "x": -88,
      "y": 2689,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 767,
    "py\/object": "star.Star"
  },
  {
    "name": "768",
    "position": {
      "x": 1604,
      "y": 2690,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 768,
    "py\/object": "star.Star"
  },
  {
    "name": "769",
    "position": {
      "x": -169,
      "y": 2696,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 769,
    "py\/object": "star.Star"
  },
  {
    "name": "770",
    "position": {
      "x": 699,
      "y": 2699,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 770,
    "py\/object": "star.Star"
  },
  {
    "name": "771",
    "position": {
      "x": 212,
      "y": 2697,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 771,
    "py\/object": "star.Star"
  },
  {
    "name": "772",
    "position": {
      "x": -226,
      "y": 2699,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 772,
    "py\/object": "star.Star"
  },
  {
    "name": "773",
    "position": {
      "x": -284,
      "y": 2711,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 773,
    "py\/object": "star.Star"
  },
  {
    "name": "774",
    "position": {
      "x": -146,
      "y": 2712,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 774,
    "py\/object": "star.Star"
  },
  {
    "name": "775",
    "position": {
      "x": 983,
      "y": 2714,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 775,
    "py\/object": "star.Star"
  },
  {
    "name": "776",
    "position": {
      "x": 375,
      "y": 2713,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 776,
    "py\/object": "star.Star"
  },
  {
    "name": "777",
    "position": {
      "x": -1252,
      "y": 2714,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 777,
    "py\/object": "star.Star"
  },
  {
    "name": "778",
    "position": {
      "x": -54,
      "y": 2725,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 778,
    "py\/object": "star.Star"
  },
  {
    "name": "779",
    "position": {
      "x": 1135,
      "y": 2727,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 779,
    "py\/object": "star.Star"
  },
  {
    "name": "780",
    "position": {
      "x": -1170,
      "y": 2725,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 780,
    "py\/object": "star.Star"
  },
  {
    "name": "781",
    "position": {
      "x": -201,
      "y": 2729,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 781,
    "py\/object": "star.Star"
  },
  {
    "name": "782",
    "position": {
      "x": 677,
      "y": 2742,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 782,
    "py\/object": "star.Star"
  },
  {
    "name": "783",
    "position": {
      "x": -579,
      "y": 2741,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 783,
    "py\/object": "star.Star"
  },
  {
    "name": "784",
    "position": {
      "x": -216,
      "y": 2748,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 784,
    "py\/object": "star.Star"
  },
  {
    "name": "785",
    "position": {
      "x": 1309,
      "y": 2752,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 785,
    "py\/object": "star.Star"
  },
  {
    "name": "786",
    "position": {
      "x": 869,
      "y": 2752,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 786,
    "py\/object": "star.Star"
  },
  {
    "name": "787",
    "position": {
      "x": -112,
      "y": 2755,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 787,
    "py\/object": "star.Star"
  },
  {
    "name": "788",
    "position": {
      "x": 1109,
      "y": 2757,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 788,
    "py\/object": "star.Star"
  },
  {
    "name": "789",
    "position": {
      "x": -173,
      "y": 2754,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 789,
    "py\/object": "star.Star"
  },
  {
    "name": "790",
    "position": {
      "x": 933,
      "y": 2760,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 790,
    "py\/object": "star.Star"
  },
  {
    "name": "791",
    "position": {
      "x": -1450,
      "y": 2761,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 791,
    "py\/object": "star.Star"
  },
  {
    "name": "792",
    "position": {
      "x": 212,
      "y": 2772,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 792,
    "py\/object": "star.Star"
  },
  {
    "name": "793",
    "position": {
      "x": -487,
      "y": 2787,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 793,
    "py\/object": "star.Star"
  },
  {
    "name": "794",
    "position": {
      "x": 1455,
      "y": 2787,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 794,
    "py\/object": "star.Star"
  },
  {
    "name": "795",
    "position": {
      "x": 1033,
      "y": 2792,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 795,
    "py\/object": "star.Star"
  },
  {
    "name": "796",
    "position": {
      "x": -1601,
      "y": 2793,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 796,
    "py\/object": "star.Star"
  },
  {
    "name": "797",
    "position": {
      "x": 955,
      "y": 2801,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 797,
    "py\/object": "star.Star"
  },
  {
    "name": "798",
    "position": {
      "x": 364,
      "y": 2808,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 798,
    "py\/object": "star.Star"
  },
  {
    "name": "799",
    "position": {
      "x": -202,
      "y": 2819,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 799,
    "py\/object": "star.Star"
  },
  {
    "name": "800",
    "position": {
      "x": 743,
      "y": 2823,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 800,
    "py\/object": "star.Star"
  },
  {
    "name": "801",
    "position": {
      "x": 515,
      "y": 2825,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 801,
    "py\/object": "star.Star"
  },
  {
    "name": "802",
    "position": {
      "x": -1450,
      "y": 2825,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 802,
    "py\/object": "star.Star"
  },
  {
    "name": "803",
    "position": {
      "x": -992,
      "y": 2826,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 803,
    "py\/object": "star.Star"
  },
  {
    "name": "804",
    "position": {
      "x": -729,
      "y": 2827,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 804,
    "py\/object": "star.Star"
  },
  {
    "name": "805",
    "position": {
      "x": 1689,
      "y": 2828,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 805,
    "py\/object": "star.Star"
  },
  {
    "name": "806",
    "position": {
      "x": -1688,
      "y": 2830,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 806,
    "py\/object": "star.Star"
  },
  {
    "name": "807",
    "position": {
      "x": 854,
      "y": 2835,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 807,
    "py\/object": "star.Star"
  },
  {
    "name": "808",
    "position": {
      "x": -1168,
      "y": 2837,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 808,
    "py\/object": "star.Star"
  },
  {
    "name": "809",
    "position": {
      "x": 1193,
      "y": 2841,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 809,
    "py\/object": "star.Star"
  },
  {
    "name": "810",
    "position": {
      "x": 1407,
      "y": 2840,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 810,
    "py\/object": "star.Star"
  },
  {
    "name": "811",
    "position": {
      "x": -10,
      "y": 2841,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 811,
    "py\/object": "star.Star"
  },
  {
    "name": "812",
    "position": {
      "x": 87,
      "y": 2848,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 812,
    "py\/object": "star.Star"
  },
  {
    "name": "813",
    "position": {
      "x": -1489,
      "y": 2857,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 813,
    "py\/object": "star.Star"
  },
  {
    "name": "814",
    "position": {
      "x": -1304,
      "y": 2861,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 814,
    "py\/object": "star.Star"
  },
  {
    "name": "815",
    "position": {
      "x": 1308,
      "y": 2864,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 815,
    "py\/object": "star.Star"
  },
  {
    "name": "816",
    "position": {
      "x": -1077,
      "y": 2869,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 816,
    "py\/object": "star.Star"
  },
  {
    "name": "817",
    "position": {
      "x": -150,
      "y": 2878,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 817,
    "py\/object": "star.Star"
  },
  {
    "name": "818",
    "position": {
      "x": -94,
      "y": 2886,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 818,
    "py\/object": "star.Star"
  },
  {
    "name": "819",
    "position": {
      "x": 1489,
      "y": 2890,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 819,
    "py\/object": "star.Star"
  },
  {
    "name": "820",
    "position": {
      "x": -725,
      "y": 2893,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 820,
    "py\/object": "star.Star"
  },
  {
    "name": "821",
    "position": {
      "x": 256,
      "y": 2895,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 821,
    "py\/object": "star.Star"
  },
  {
    "name": "822",
    "position": {
      "x": 1197,
      "y": 2899,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 822,
    "py\/object": "star.Star"
  },
  {
    "name": "823",
    "position": {
      "x": 1506,
      "y": 2907,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 823,
    "py\/object": "star.Star"
  },
  {
    "name": "824",
    "position": {
      "x": 12,
      "y": 2912,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 824,
    "py\/object": "star.Star"
  },
  {
    "name": "825",
    "position": {
      "x": -1237,
      "y": 2916,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 825,
    "py\/object": "star.Star"
  },
  {
    "name": "826",
    "position": {
      "x": 946,
      "y": 2919,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 826,
    "py\/object": "star.Star"
  },
  {
    "name": "827",
    "position": {
      "x": 1051,
      "y": 2927,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 827,
    "py\/object": "star.Star"
  },
  {
    "name": "828",
    "position": {
      "x": -1155,
      "y": 2944,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 828,
    "py\/object": "star.Star"
  },
  {
    "name": "829",
    "position": {
      "x": 1341,
      "y": 2967,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 829,
    "py\/object": "star.Star"
  },
  {
    "name": "830",
    "position": {
      "x": 780,
      "y": 2988,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 830,
    "py\/object": "star.Star"
  },
  {
    "name": "831",
    "position": {
      "x": 178,
      "y": 2987,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 831,
    "py\/object": "star.Star"
  },
  {
    "name": "832",
    "position": {
      "x": -409,
      "y": 3003,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 832,
    "py\/object": "star.Star"
  },
  {
    "name": "833",
    "position": {
      "x": 460,
      "y": 3028,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 833,
    "py\/object": "star.Star"
  },
  {
    "name": "834",
    "position": {
      "x": 1620,
      "y": 3039,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 834,
    "py\/object": "star.Star"
  },
  {
    "name": "835",
    "position": {
      "x": 82,
      "y": 3052,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 835,
    "py\/object": "star.Star"
  },
  {
    "name": "836",
    "position": {
      "x": -106,
      "y": 3091,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 836,
    "py\/object": "star.Star"
  },
  {
    "name": "837",
    "position": {
      "x": 898,
      "y": 3098,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 837,
    "py\/object": "star.Star"
  },
  {
    "name": "838",
    "position": {
      "x": -709,
      "y": 3115,
      "py\/object": "star.Position"
    },
    "owner": {
      "id": "1",
      "py\/object": "star.Owner"
    },
    "id": 838,
    "py\/object": "star.Star"
  }
]